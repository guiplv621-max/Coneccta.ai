/* ============================================================
   CONECTTA.AI — Dados de demonstração (pt-BR)
   Dados fictícios para demonstração. Datas são geradas de forma
   relativa à data atual (mantém a demonstração sempre "viva").
   Schema de lead: id, nome, empresa, whatsapp, entrada, origem,
   intencao, servico, pri, respId, status, valor, ultima,
   tempoResp (horas), prob, urgente, msgs, motivo (se perdido)
   ============================================================ */
window.DB = {
  "currentUser": {
    "id": "e1",
    "name": "Rafael Almeida",
    "role": "Administrador",
    "email": "rafael@horizonte.digital"
  },
  "permissions": {
    "Administrador": [
      "dashboard",
      "leads",
      "perdidos",
      "reunioes",
      "templates",
      "equipe",
      "roteamento",
      "analytics",
      "config"
    ],
    "Gerente": [
      "dashboard",
      "leads",
      "perdidos",
      "reunioes",
      "equipe",
      "roteamento",
      "analytics"
    ],
    "Vendedor": [
      "dashboard",
      "leads",
      "reunioes",
      "templates"
    ],
    "Atendimento": [
      "dashboard",
      "leads",
      "reunioes",
      "templates"
    ]
  },
  "employees": [
    {
      "id": "e1",
      "name": "Rafael Almeida",
      "role": "Administrador",
      "dept": "Direção",
      "active": true,
      "color": "#4f46e5",
      "spec": [
        "Gestão",
        "Estratégia",
        "Parcerias"
      ],
      "workload": 20,
      "convRate": 0,
      "respAvg": 0,
      "senior": "sênior",
      "phone": "(11) 99900-0001"
    },
    {
      "id": "e2",
      "name": "Carla Mendes",
      "role": "Gerente",
      "dept": "Vendas",
      "active": true,
      "color": "#0ea5e9",
      "spec": [
        "Vendas",
        "Gestão de equipe",
        "Reclamações"
      ],
      "workload": 60,
      "convRate": 41,
      "respAvg": 4.2,
      "seniority": "sênior",
      "phone": "(11) 99900-0002"
    },
    {
      "id": "e3",
      "name": "Carlos Ferreira",
      "role": "Vendedor Sênior",
      "dept": "Vendas",
      "active": true,
      "color": "#10b981",
      "spec": [
        "Site",
        "Branding",
        "Tráfego pago"
      ],
      "workload": 75,
      "convRate": 47,
      "respAvg": 3.1,
      "seniority": "sênior",
      "phone": "(11) 99900-0003"
    },
    {
      "id": "e4",
      "name": "Juliana Costa",
      "role": "Vendedor",
      "dept": "Vendas",
      "active": true,
      "color": "#f59e0b",
      "spec": [
        "Social media",
        "Site",
        "Anúncios"
      ],
      "workload": 55,
      "convRate": 32,
      "respAvg": 6.8,
      "seniority": "pleno",
      "phone": "(11) 99900-0004"
    },
    {
      "id": "e5",
      "name": "Pedro Santos",
      "role": "Vendedor Júnior",
      "dept": "Vendas",
      "active": true,
      "color": "#8b5cf6",
      "spec": [
        "Social media",
        "Atendimento"
      ],
      "workload": 40,
      "convRate": 18,
      "respAvg": 9.4,
      "seniority": "júnior",
      "phone": "(11) 99900-0005"
    },
    {
      "id": "e6",
      "name": "Marina Souza",
      "role": "Atendimento",
      "dept": "Atendimento",
      "active": true,
      "color": "#ec4899",
      "spec": [
        "Atendimento geral",
        "Triagem",
        "Perguntas"
      ],
      "workload": 50,
      "convRate": 25,
      "respAvg": 4,
      "seniority": "pleno",
      "phone": "(11) 99900-0006"
    },
    {
      "id": "e7",
      "name": "Tiago Lima",
      "role": "Financeiro",
      "dept": "Financeiro",
      "active": true,
      "color": "#14b8a6",
      "spec": [
        "Financeiro",
        "Faturamento",
        "Cobranças"
      ],
      "workload": 35,
      "convRate": 0,
      "respAvg": 12.5,
      "seniority": "pleno",
      "phone": "(11) 99900-0007"
    },
    {
      "id": "e8",
      "name": "Larissa Rocha",
      "role": "Designer",
      "dept": "Criativo",
      "active": true,
      "color": "#a855f7",
      "spec": [
        "Branding",
        "Design",
        "Identidade visual"
      ],
      "workload": 70,
      "convRate": 38,
      "respAvg": 7.2,
      "seniority": "sênior",
      "phone": "(11) 99900-0008"
    },
    {
      "id": "e9",
      "name": "André Martins",
      "role": "Social Media",
      "dept": "Criativo",
      "active": true,
      "color": "#f43f5e",
      "spec": [
        "Social media",
        "Conteúdo"
      ],
      "workload": 45,
      "convRate": 29,
      "respAvg": 5.6,
      "seniority": "pleno",
      "phone": "(11) 99900-0009"
    },
    {
      "id": "e10",
      "name": "Renata Nunes",
      "role": "Suporte",
      "dept": "Suporte",
      "active": true,
      "color": "#0891b2",
      "spec": [
        "Suporte",
        "Atendimento"
      ],
      "workload": 40,
      "convRate": 0,
      "respAvg": 3.8,
      "seniority": "pleno",
      "phone": "(11) 99900-0010"
    },
    {
      "id": "e11",
      "name": "Gustavo Prado",
      "role": "Atendimento",
      "dept": "Atendimento",
      "active": false,
      "color": "#94a3b8",
      "spec": [
        "Atendimento"
      ],
      "workload": 0,
      "convRate": 0,
      "respAvg": 0,
      "seniority": "júnior",
      "phone": "(11) 99900-0011"
    }
  ],
  "rules": [
    {
      "id": "r1",
      "ic": "🌐",
      "intent": "Venda",
      "servico": "Desenvolvimento de site",
      "to": "Carlos Ferreira — Vendedor Sênior",
      "toId": "e3",
      "pri": "Alta"
    },
    {
      "id": "r2",
      "ic": "📈",
      "intent": "Venda",
      "servico": "Tráfego pago",
      "to": "Juliana Costa — Vendas",
      "toId": "e4",
      "pri": "Alta"
    },
    {
      "id": "r3",
      "ic": "🎨",
      "intent": "Venda",
      "servico": "Branding / Design",
      "to": "Larissa Rocha — Especialista Criativo",
      "toId": "e8",
      "pri": "Média"
    },
    {
      "id": "r4",
      "ic": "📣",
      "intent": "Venda",
      "servico": "Social media",
      "to": "André Martins — Social Media",
      "toId": "e9",
      "pri": "Média"
    },
    {
      "id": "r5",
      "ic": "💰",
      "intent": "Orçamento",
      "servico": "Qualquer",
      "to": "Carlos Ferreira — Vendedor Sênior",
      "toId": "e3",
      "pri": "Alta"
    },
    {
      "id": "r6",
      "ic": "🚨",
      "intent": "Reclamação",
      "servico": "Qualquer",
      "to": "Carla Mendes — Gerente",
      "toId": "e2",
      "pri": "Crítica"
    },
    {
      "id": "r7",
      "ic": "✂️",
      "intent": "Cancelamento",
      "servico": "Qualquer",
      "to": "Carla Mendes — Gerente",
      "toId": "e2",
      "pri": "Crítica"
    },
    {
      "id": "r8",
      "ic": "💳",
      "intent": "Financeiro",
      "servico": "Qualquer",
      "to": "Tiago Lima — Financeiro",
      "toId": "e7",
      "pri": "Média"
    },
    {
      "id": "r9",
      "ic": "🛠️",
      "intent": "Suporte",
      "servico": "Qualquer",
      "to": "Renata Nunes — Suporte",
      "toId": "e10",
      "pri": "Alta"
    },
    {
      "id": "r10",
      "ic": "💎",
      "intent": "Lead alto valor",
      "servico": "Qualquer",
      "to": "Carlos Ferreira — Vendedor Sênior",
      "toId": "e3",
      "pri": "Alta"
    },
    {
      "id": "r11",
      "ic": "👋",
      "intent": "Pergunta geral",
      "servico": "Qualquer",
      "to": "Marina Souza — Atendimento",
      "toId": "e6",
      "pri": "Baixa"
    },
    {
      "id": "r12",
      "ic": "📅",
      "intent": "Reunião",
      "servico": "Qualquer",
      "to": "Responsável do lead",
      "toId": "e2",
      "pri": "Média"
    }
  ],
  "intents": [
    "Novo orçamento",
    "Proposta",
    "Negociação",
    "Follow-up",
    "Upsell",
    "Suporte",
    "Pergunta",
    "Reclamação",
    "Cancelamento",
    "Revisão",
    "Financeiro",
    "Reunião",
    "Parceria"
  ],
  "services": [
    "Desenvolvimento de site",
    "Tráfego pago",
    "Social media",
    "Branding",
    "Design",
    "Identidade visual",
    "Consultoria",
    "Anúncios"
  ],
  "statuses": [
    "Novo",
    "Em atendimento",
    "Qualificado",
    "Proposta enviada",
    "Negociação",
    "Convertido",
    "Perdido",
    "Cancelado"
  ],
  "priorities": [
    "Baixa",
    "Média",
    "Alta",
    "Crítica"
  ],
  "leads": [
    {
      "id": "L-1042",
      "nome": "Marcos Vinícius",
      "empresa": "Padaria Pão Dourado",
      "whatsapp": "(11) 98001-1042",
      "entrada": "2026-08-16T07:12:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Novo orçamento",
      "servico": "Desenvolvimento de site",
      "pri": "Alta",
      "respId": "e3",
      "status": "Negociação",
      "valor": 12500,
      "ultima": "2026-08-16T08:40:00.000Z",
      "tempoResp": 4,
      "prob": 62,
      "urgente": false,
      "msg": "Olá, preciso de um site para minha empresa. Queremos algo profissional e precisamos saber quanto custa."
    },
    {
      "id": "L-1041",
      "nome": "Ana Beatriz",
      "empresa": "Clínica Vitalle",
      "whatsapp": "(11) 98801-1048",
      "entrada": "2026-08-16T05:45:00.000Z",
      "origem": "Instagram",
      "intencao": "Proposta",
      "servico": "Branding",
      "pri": "Média",
      "respId": "e8",
      "status": "Proposta enviada",
      "valor": 3200,
      "ultima": "2026-08-16T07:15:00.000Z",
      "prob": 58,
      "urgente": false,
      "msg": [
        "Preciso de uma identidade visual nova para minha clínica."
      ]
    },
    {
      "id": "L-1040",
      "nome": "Diego Rocha",
      "empresa": "Ret Peças",
      "whatsapp": "(11) 97701-1041",
      "entrada": "2026-08-15T14:20:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Reclamação",
      "servico": "Tráfego pago",
      "pri": "Crítica",
      "respId": "e2",
      "status": "Em atendimento",
      "valor": 0,
      "ultima": "2026-08-15T15:00:00.000Z",
      "prob": 10,
      "urgente": true,
      "msg": [
        "Minha campanha está com erro desde ontem e ninguém resolveu!",
        "Preciso de uma solução agora."
      ]
    },
    {
      "id": "L-1039",
      "nome": "Fernanda Dias",
      "empresa": "Studio Fernanda Dias",
      "whatsapp": "(11) 96601-1042",
      "entrada": "2026-08-15T12:00:00.000Z",
      "origem": "Indicação",
      "intencao": "Novo orçamento",
      "servico": "Social media",
      "pri": "Média",
      "respId": null,
      "status": "Novo",
      "valor": 1900,
      "ultima": "2026-08-15T12:00:00.000Z",
      "prob": 30,
      "urgente": false,
      "msg": [
        "Oi! Vocês cuidam de redes sociais para estúdio de beleza?"
      ]
    },
    {
      "id": "L-1038",
      "nome": "Otávio Sampaio",
      "empresa": "Construtora Horizonte",
      "whatsapp": "(11) 98901-1001",
      "entrada": "2026-08-14T09:30:00.000Z",
      "origem": "Site",
      "intencao": "Proposta",
      "servico": "Tráfego pago",
      "pri": "Alta",
      "respId": "e4",
      "status": "Qualificado",
      "valor": 5800,
      "ultima": "2026-08-14T10:00:00.000Z",
      "prob": 65,
      "urgente": false,
      "msg": [
        "Preciso impulsionar a construtora. Podem preparar proposta?"
      ]
    },
    {
      "id": "L-1037",
      "nome": "Juliana Castro",
      "empresa": "Café Aurora",
      "whatsapp": "(11) 97901-1002",
      "entrada": "2026-08-13T13:40:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Negociação",
      "servico": "Desenvolvimento de site",
      "pri": "Alta",
      "respId": "e3",
      "status": "Convertido",
      "valor": 6500,
      "ultima": "2026-08-15T09:00:00.000Z",
      "prob": 100,
      "urgente": false,
      "msg": [
        "Fechamos! Vamos em frente com o site."
      ]
    },
    {
      "id": "L-1036",
      "nome": "Roberto Carvalho",
      "empresa": "Transportes VC",
      "whatsapp": "(11) 96901-1003",
      "entrada": "2026-08-13T07:05:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Consultoria",
      "pri": "Média",
      "respId": "e6",
      "status": "Em atendimento",
      "valor": 1500,
      "ultima": "2026-08-13T07:20:00.000Z",
      "prob": 40,
      "urgente": false
    },
    {
      "id": "L-1035",
      "nome": "Patrícia Melo",
      "empresa": "Clínica Dental Nova",
      "whatsapp": "(11) 95901-1004",
      "entrada": "2026-08-12T11:10:00.000Z",
      "origem": "Instagram",
      "intencao": "Proposta",
      "servico": "Anúncios",
      "pri": "Alta",
      "respId": "e3",
      "status": "Qualificado",
      "valor": 4200,
      "ultima": "2026-08-14T08:00:00.000Z",
      "prob": 60,
      "urgente": false
    },
    {
      "id": "L-1034",
      "nome": "Sérgio Andrade",
      "empresa": "Imobiliária Norte",
      "whatsapp": "(11) 94901-1005",
      "entrada": "2026-08-12T06:00:00.000Z",
      "origem": "Indicação",
      "intencao": "Follow-up",
      "servico": "Tráfego pago",
      "pri": "Média",
      "respId": "e4",
      "status": "Proposta enviada",
      "valor": 3800,
      "ultima": "2026-08-14T07:00:00.000Z",
      "prob": 55,
      "urgente": false
    },
    {
      "id": "L-1033",
      "nome": "Cláudia Ferreira",
      "empresa": "Loja Moda Atual",
      "whatsapp": "(11) 93901-1006",
      "entrada": "2026-08-11T08:30:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Cancelamento",
      "servico": "Social media",
      "pri": "Crítica",
      "respId": "e2",
      "status": "Cancelado",
      "valor": 0,
      "ultima": "2026-08-11T08:45:00.000Z",
      "prob": 0,
      "urgente": true
    },
    {
      "id": "L-1032",
      "nome": "Renan Pereira",
      "empresa": "Fitness Life",
      "whatsapp": "(11) 92901-1007",
      "entrada": "2026-08-10T16:20:00.000Z",
      "origem": "Facebook",
      "intencao": "Novo orçamento",
      "servico": "Social media",
      "pri": "Média",
      "respId": "e9",
      "status": "Em atendimento",
      "valor": 2000,
      "ultima": "2026-08-10T16:40:00.000Z",
      "prob": 45,
      "urgente": false
    },
    {
      "id": "L-1031",
      "nome": "Beatriz Nogueira",
      "empresa": "Doçaria Sabor & Arte",
      "whatsapp": "(11) 91901-1008",
      "entrada": "2026-08-10T07:50:00.000Z",
      "origem": "Indicação",
      "intencao": "Novo orçamento",
      "servico": "Branding",
      "pri": "Média",
      "respId": "e8",
      "status": "Proposta enviada",
      "valor": 1800,
      "ultima": "2026-08-11T08:00:00.000Z",
      "prob": 50,
      "urgente": false
    },
    {
      "id": "L-1030",
      "nome": "Lucas Figueiredo",
      "empresa": "Tech Solutions BR",
      "whatsapp": "(11) 90901-1009",
      "entrada": "2026-08-09T12:00:00.000Z",
      "origem": "Site",
      "intencao": "Negociação",
      "servico": "Desenvolvimento de site",
      "pri": "Alta",
      "respId": "e3",
      "status": "Negociação",
      "valor": 7800,
      "ultima": "2026-08-13T07:00:00.000Z",
      "prob": 75,
      "urgente": false
    },
    {
      "id": "L-1029",
      "nome": "Isabela Rocha",
      "empresa": "Isabela Advogada",
      "whatsapp": "(11) 89901-1010",
      "entrada": "2026-08-08T09:20:00.000Z",
      "origem": "Instagram",
      "intencao": "Proposta",
      "servico": "Identidade visual",
      "pri": "Média",
      "respId": "e8",
      "status": "Qualificado",
      "valor": 2400,
      "ultima": "2026-08-09T07:00:00.000Z",
      "prob": 55,
      "urgente": false
    },
    {
      "id": "L-1028",
      "nome": "Anderson Cruz",
      "empresa": "Oficina Turbo",
      "whatsapp": "(11) 88901-1011",
      "entrada": "2026-08-08T14:00:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Reclamação",
      "servico": "Suporte",
      "pri": "Crítica",
      "respId": "e2",
      "status": "Em atendimento",
      "valor": 0,
      "ultima": "2026-08-08T14:20:00.000Z",
      "prob": 0,
      "urgente": true
    },
    {
      "id": "L-1027",
      "nome": "Carla Prado",
      "empresa": "Café Expresso",
      "whatsapp": "(11) 87901-1012",
      "entrada": "2026-08-07T08:15:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Consultoria",
      "pri": "Média",
      "respId": "e6",
      "status": "Em atendimento",
      "valor": 900,
      "ultima": "2026-08-07T08:30:00.000Z",
      "prob": 35,
      "urgente": false
    },
    {
      "id": "L-1026",
      "nome": "Rodrigo Alves",
      "empresa": "Tech Acesso",
      "whatsapp": "(11) 86901-1013",
      "entrada": "2026-08-06T11:40:00.000Z",
      "origem": "Indicação",
      "intencao": "Novo orçamento",
      "servico": "Tráfego pago",
      "pri": "Alta",
      "respId": "e4",
      "status": "Proposta enviada",
      "valor": 4500,
      "ultima": "2026-08-07T07:00:00.000Z",
      "prob": 58,
      "urgente": false
    },
    {
      "id": "L-1025",
      "nome": "Tatiana Lima",
      "empresa": "Estúdio Beleza Viva",
      "whatsapp": "(11) 85901-1014",
      "entrada": "2026-08-06T07:00:00.000Z",
      "origem": "Instagram",
      "intencao": "Follow-up",
      "servico": "Social media",
      "pri": "Baixa",
      "respId": "e9",
      "status": "Qualificado",
      "valor": 1200,
      "ultima": "2026-08-07T08:00:00.000Z",
      "prob": 42,
      "urgente": false
    },
    {
      "id": "L-1024",
      "nome": "Vinícius Souza",
      "empresa": "ConstruMax",
      "whatsapp": "(11) 84901-1015",
      "entrada": "2026-08-05T13:00:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Desenvolvimento de site",
      "pri": "Alta",
      "respId": "e5",
      "status": "Em atendimento",
      "valor": 5200,
      "ultima": "2026-08-05T13:30:00.000Z",
      "prob": 48,
      "urgente": false
    },
    {
      "id": "L-1023",
      "nome": "Aline Martins",
      "empresa": "Boutique Elegance",
      "whatsapp": "(11) 83901-1016",
      "entrada": "2026-08-05T09:30:00.000Z",
      "origem": "Indicação",
      "intencao": "Negociação",
      "servico": "Branding",
      "pri": "Alta",
      "respId": "e8",
      "status": "Negociação",
      "valor": 3000,
      "ultima": "2026-08-08T07:00:00.000Z",
      "prob": 66,
      "urgente": false
    },
    {
      "id": "L-1022",
      "nome": "Fábio Lemos",
      "empresa": "Lemos Contabilidade",
      "whatsapp": "(11) 82901-1017",
      "entrada": "2026-08-04T12:20:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Anúncios",
      "pri": "Média",
      "respId": "e6",
      "status": "Em atendimento",
      "valor": 1800,
      "ultima": "2026-08-04T12:40:00.000Z",
      "prob": 38,
      "urgente": false
    },
    {
      "id": "L-1021",
      "nome": "Vera Antunes",
      "empresa": "Antunes Incorporadora",
      "whatsapp": "(11) 81901-1018",
      "entrada": "2026-08-04T08:00:00.000Z",
      "origem": "WhatsApp",
      "intencao": "Novo orçamento",
      "servico": "Desenvolvimento de site",
      "pri": "Crítica",
      "respId": "e3",
      "status": "Qualificado",
      "valor": 12000,
      "ultima": "2026-08-06T07:00:00.000Z",
      "prob": 70,
      "urgente": false
    },
    {
      "id": "L-1020",
      "nome": "Marcelo Dias",
      "empresa": "Dias Distribuidora",
      "whatsapp": "(11) 80901-1019",
      "entrada": "2026-08-03T12:00:00.000Z",
      "origem": "Site",
      "intencao": "Suporte",
      "servico": "Tráfego pago",
      "pri": "Média",
      "respId": "e10",
      "status": "Em atendimento",
      "valor": 0,
      "ultima": "2026-08-03T12:20:00.000Z",
      "prob": 0,
      "urgente": false
    },
    {
      "id": "L-1019",
      "nome": "Camila Torres",
      "empresa": "Torres Arquitetura",
      "whatsapp": "(11) 79901-1020",
      "entrada": "2026-08-03T07:30:00.000Z",
      "origem": "Instagram",
      "intencao": "Novo orçamento",
      "servico": "Branding",
      "pri": "Média",
      "respId": "e8",
      "status": "Novo",
      "valor": 2800,
      "ultima": "2026-08-03T07:30:00.000Z",
      "prob": 30,
      "urgente": false
    },
    {
      "id": "L-1018",
      "nome": "Hugo Lima",
      "empresa": "Tech Serviços",
      "whatsapp": "(11) 78901-1021",
      "entrada": "2026-08-02T15:30:00.000Z",
      "origem": "Indicação",
      "intencao": "Novo orçamento",
      "servico": "Consultoria",
      "pri": "Baixa",
      "respId": "e6",
      "status": "Qualificado",
      "valor": 800,
      "ultima": "2026-08-03T07:00:00.000Z",
      "prob": 40,
      "urgente": false
    },
    {
      "id": "L-1017",
      "nome": "Daniela Sá",
      "empresa": "Sá Restaurante",
      "whatsapp": "(11) 77901-1022",
      "entrada": "2026-08-02T10:00:00.000Z",
      "origem": "Instagram",
      "intencao": "Novo orçamento",
      "servico": "Social media",
      "pri": "Média",
      "respId": "e9",
      "status": "Proposta enviada",
      "valor": 1500,
      "ultima": "2026-08-03T08:00:00.000Z",
      "prob": 52,
      "urgente": false
    },
    {
      "id": "L-1016",
      "nome": "Fábio Lemos",
      "empresa": "Lemos Contabilidade",
      "whatsapp": "(11) 82901-1023",
      "entrada": "2026-08-01T09:00:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Consultoria",
      "pri": "Baixa",
      "respId": "e6",
      "status": "Convertido",
      "valor": 700,
      "ultima": "2026-08-01T09:20:00.000Z",
      "prob": 100,
      "urgente": false
    },
    {
      "id": "L-1015",
      "nome": "Mônica Vilela",
      "empresa": "Vilela Odontologia",
      "whatsapp": "(11) 81901-1024",
      "entrada": "2026-07-31T08:00:00.000Z",
      "origem": "Site",
      "intencao": "Novo orçamento",
      "servico": "Tráfego pago",
      "pri": "Média",
      "respId": "e4",
      "status": "Convertido",
      "valor": 3600,
      "ultima": "2026-07-31T08:30:00.000Z",
      "prob": 100,
      "urgente": false
    }
  ],
  "lostLeads": [
    {
      "nome": "Roberto Campos",
      "empresa": "Campos Distribuidora",
      "valor": 4200,
      "motivo": "Resposta demorada",
      "respId": "e5",
      "tempoResp": 24,
      "etapa": "Negociação",
      "data": "2026-08-09"
    },
    {
      "nome": "Sônia Moraes",
      "empresa": "Morais Estética",
      "valor": 2600,
      "motivo": "Resposta demorada",
      "respId": "e4",
      "tempoResp": 20,
      "etapa": "Proposta",
      "data": "2026-08-08"
    },
    {
      "nome": "Evandro Reis",
      "empresa": "Reis Construções",
      "valor": 6800,
      "motivo": "Roteamento incorreto",
      "respId": "e5",
      "tempoResp": 18,
      "etapa": "Negociação",
      "data": "2026-08-06"
    },
    {
      "nome": "Mariana Faria",
      "empresa": "Farmácia Vida",
      "valor": 3400,
      "motivo": "Resposta demorada",
      "respId": "e6",
      "tempoResp": 30,
      "etapa": "Novo",
      "data": "2026-08-04"
    },
    {
      "nome": "João Neves",
      "empresa": "Neves Alimentos",
      "valor": 1800,
      "motivo": "Atendimento ruim",
      "respId": "e11",
      "tempoResp": 12,
      "etapa": "Proposta",
      "data": "2026-08-02"
    },
    {
      "nome": "Paula Campos",
      "empresa": "Studio Pilates",
      "valor": 2100,
      "motivo": "Resposta demorada",
      "respId": "e5",
      "tempoResp": 22,
      "etapa": "Negociação",
      "data": "2026-08-01"
    },
    {
      "nome": "Márcio Teixeira",
      "empresa": "Teixeira Modas",
      "valor": 5400,
      "motivo": "Roteamento incorreto",
      "respId": "e11",
      "tempoResp": 20,
      "etapa": "Proposta",
      "data": "2026-07-30"
    },
    {
      "nome": "Elaine Pires",
      "empresa": "Pires Advocacia",
      "valor": 4100,
      "motivo": "Concorrência",
      "respId": "e4",
      "tempoResp": 14,
      "etapa": "Negociação",
      "data": "2026-07-28"
    },
    {
      "nome": "César Mota",
      "empresa": "Mota Logística",
      "valor": 7200,
      "motivo": "Preço",
      "respId": "e3",
      "tempoResp": 8,
      "etapa": "Proposta",
      "data": "2026-07-27"
    },
    {
      "nome": "Rosângela Dias",
      "empresa": "Studio Jóias",
      "valor": 2900,
      "motivo": "Resposta demorada",
      "respId": "e6",
      "tempoResp": 35,
      "etapa": "Novo",
      "data": "2026-07-26"
    }
  ],
  "meetings": [
    {
      "id": "m1",
      "nome": "Marcos Vinícius",
      "empresa": "Padaria Pão Dourado",
      "clienteId": "L-1042",
      "empId": "e3",
      "tipo": "Apresentação de proposta",
      "data": "2026-08-17T08:00:00.000Z",
      "status": "Confirmada",
      "nota": "Cliente pediu prazo de 15 dias. Apresentar portfólio de sites.",
      "link": ""
    },
    {
      "id": "m2",
      "nome": "Fernanda Dias",
      "empresa": "Studio Fernanda Dias",
      "clienteId": "L-1039",
      "empId": "e4",
      "tipo": "Sessão de descoberta",
      "data": "2026-08-18T12:30:00.000Z",
      "status": "Agendada",
      "nota": "Entender objetivo de redes sociais.",
      "link": ""
    },
    {
      "id": "m3",
      "nome": "Otávio Siqueira",
      "empresa": "Construtora Horizonte",
      "clienteId": "L-1038",
      "empId": "e3",
      "tipo": "Proposta comercial",
      "data": "2026-08-19T07:00:00.000Z",
      "status": "Agendada",
      "nota": "",
      "link": ""
    },
    {
      "id": "m4",
      "nome": "Juliana Castro",
      "empresa": "Café",
      "clienteId": "L-1037",
      "empId": "e3",
      "tipo": "Negociação de contrato",
      "data": "2026-08-16T13:00:00.000Z",
      "status": "Confirmada",
      "nota": "Discutir escopo do site e pagamento.",
      "link": "https://meet.google.com/abc-def-ghi"
    },
    {
      "id": "m5",
      "nome": "Paulo Varejão",
      "empresa": "Varejo Sul",
      "clienteId": null,
      "empId": "e2",
      "tipo": "Follow-up",
      "data": "2026-08-12T09:00:00.000Z",
      "status": "Realizada",
      "nota": "Cliente decidiu aguardar orçamento de concorrente.",
      "link": ""
    },
    {
      "id": "m6",
      "nome": "Ana Beatriz",
      "empresa": "Clínica Vitalle",
      "clienteId": "L-1041",
      "empId": "e8",
      "tipo": "Briefing de branding",
      "data": "2026-08-11T08:30:00.000Z",
      "status": "Realizada",
      "nota": "Entregue direcionamento visual.",
      "link": "https://meet.google.com/abc-123"
    },
    {
      "id": "m7",
      "nome": "Lucas Figueiredo",
      "empresa": "Tech Solutions BR",
      "clienteId": "L-1030",
      "empId": "e3",
      "tipo": "Negociação",
      "data": "2026-08-13T07:00:00.000Z",
      "status": "Reagendada",
      "nota": "Adiar para semana seguinte.",
      "link": ""
    },
    {
      "id": "m8",
      "nome": "Renan Pereira",
      "empresa": "Fitness Life",
      "clienteId": "L-1032",
      "empId": "e9",
      "tipo": "Sessão de escopo",
      "data": "2026-08-08T14:00:00.000Z",
      "status": "Realizada",
      "nota": "Escopo de redes sociais definido.",
      "link": ""
    },
    {
      "id": "m9",
      "nome": "Sérgio Andrade",
      "empresa": "Imobiliária Norte",
      "clienteId": "L-1034",
      "empId": "e4",
      "tipo": "Proposta",
      "data": "2026-08-09T07:30:00.000Z",
      "status": "Não compareceu",
      "nota": "Cliente não apareceu. Reagendar.",
      "link": ""
    },
    {
      "id": "m10",
      "nome": "Vinícius Souza",
      "empresa": "ConstruMax",
      "clienteId": "L-1024",
      "empId": "e5",
      "tipo": "Descoberta",
      "data": "2026-08-06T11:00:00.000Z",
      "status": "Cancelada",
      "nota": "Cliente cancelou.",
      "link": ""
    },
    {
      "id": "m11",
      "nome": "Isabela Rocha",
      "empresa": "Isabela Advogada",
      "clienteId": "L-1029",
      "empId": "e8",
      "tipo": "Briefing visual",
      "data": "2026-08-18T14:00:00.000Z",
      "status": "Agendada",
      "nota": "",
      "link": ""
    }
  ],
  "templates": [
    {
      "id": "t1",
      "cat": "Primeiro contato",
      "nome": "Boas-vindas automática",
      "msg": "Olá, {{nome}}! Recebi sua mensagem. Vou encaminhar seu atendimento para {{responsavel}}, que já vai te ajudar com {{servico}}."
    },
    {
      "id": "t2",
      "cat": "Solicitação de orçamento",
      "nome": "Orçamento recebido",
      "msg": "Olá, {{nome}}! Recebi seu pedido de orçamento sobre {{servico}}. Nossa especialista {{responsavel}} vai preparar a proposta e te responder em breve."
    },
    {
      "id": "t3",
      "cat": "Site",
      "nome": "Consulta de site",
      "msg": "Olá, {{nome}}! Sobre o desenvolvimento de site: a {{responsavel}} vai agendar um bate-papo para entender seu projeto e te passar valor e prazo."
    },
    {
      "id": "t4",
      "cat": "Tráfego pago",
      "nome": "Consulta de tráfego",
      "msg": "Olá, {{nome}}! Vamos analisar suas campanhas. {{responsavel}} vai entrar em contato para montar a estratégia de tráfego."
    },
    {
      "id": "t5",
      "cat": "Social media",
      "nome": "Gestão de redes",
      "msg": "Olá, {{nome}}! Sobre gestão de redes sociais, o {{responsavel}} vai te mostrar um plano de conteúdo e frequência de posts."
    },
    {
      "id": "t6",
      "cat": "Branding",
      "nome": "Projeto de marca",
      "msg": "Olá, {{nome}}! Seu projeto de branding está em boas mãos com {{responsavel}}. Ela vai levantar sua identidade e posicionamento."
    },
    {
      "id": "t7",
      "cat": "Reclamação",
      "nome": "Tratamento de reclamação",
      "msg": "Olá, {{nome}}, lamento muito pelo ocorrido. Seu caso é prioritário e será tratado pela gerência ({{responsavel}}) imediatamente."
    },
    {
      "id": "t8",
      "cat": "Cancelamento",
      "nome": "Solicitação de cancelamento",
      "msg": "Olá, {{nome}}, entendemos seu pedido de cancelamento. Nossa gerente {{responsavel}} vai falar com você para entender melhor e buscar a melhor solução."
    },
    {
      "id": "t9",
      "cat": "Follow-up",
      "nome": "Follow-up de proposta",
      "msg": "Olá, {{nome}}! Como está seu projeto de {{servico}}? Ficamos à disposição para tirar dúvidas e ajustar a proposta."
    },
    {
      "id": "t10",
      "cat": "Agendamento",
      "nome": "Confirmação de reunião",
      "msg": "Olá, {{nome}}! Confirma nossa reunião no dia {{data}} às {{horario}}? Acesse: {{link}}."
    },
    {
      "id": "t11",
      "cat": "Fora do horário",
      "nome": "Fora do expediente",
      "msg": "Olá, {{nome}}! Estamos fora do horário de atendimento. Sua mensagem foi analisada e nossa equipe vai te responder no próximo horário útil."
    },
    {
      "id": "t12",
      "cat": "Atendimento geral",
      "nome": "Pergunta geral",
      "msg": "Olá, {{nome}}! Recebemos sua mensagem sobre {{servico}}. Em instantes o {{responsavel}} vai te atender."
    }
  ],
  "notifications": [
    {
      "id": "n1",
      "ic": "🔥",
      "color": "var(--red-50)",
      "t": "Novo lead de alta prioridade",
      "d": "Lucas Figueiredo (Site, R$ 7.800) roteado para Carlos Ferreira.",
      "when": "agora",
      "unread": true
    },
    {
      "id": "n2",
      "ic": "⏰",
      "color": "var(--amber-50)",
      "t": "Lead sem resposta há 4h",
      "d": "Sérgio Andrade — Imobiliária Norte aguarda retorno.",
      "when": "há 15 min",
      "unread": true
    },
    {
      "id": "n3",
      "ic": "⚠️",
      "color": "var(--amber-50)",
      "t": "Lead próximo de ser perdido",
      "d": "Vinícius Souza (ConstruMax) sem contato há 3 dias.",
      "when": "há 40 min",
      "unread": true
    },
    {
      "id": "n4",
      "ic": "📅",
      "color": "var(--sky-50)",
      "t": "Nova reunião agendada",
      "d": "Fernanda Dias — Descoberta amanhã 14h30.",
      "when": "há 1h",
      "unread": true
    },
    {
      "id": "n5",
      "ic": "🚨",
      "color": "var(--red-50)",
      "t": "Reclamação recebida",
      "d": "Diego Rocha — Auto Peças. Roteado para Gerência.",
      "when": "há 2h",
      "unread": true
    },
    {
      "id": "n6",
      "ic": "✂️",
      "color": "var(--red-50)",
      "t": "Solicitação de cancelamento",
      "d": "Cláudia Ferreira — Loja Moda Atual.",
      "when": "há 3h",
      "unread": false
    },
    {
      "id": "n7",
      "ic": "🔄",
      "color": "var(--brand-50)",
      "t": "Lead reatribuído",
      "d": "Ana Beatriz — Branding movida para Larissa Rocha.",
      "when": "há 4h",
      "unread": false
    },
    {
      "id": "n8",
      "ic": "✅",
      "color": "var(--green-50)",
      "t": "Conversão registrada",
      "d": "Juliana Castro — Café fechou projeto de site.",
      "when": "ontem",
      "unread": false
    }
  ]
};
