/* ============================================================
   CONECTTA.AI — Aplicação (pt-BR)
   Lógica do produto, navegação, renderização e interações.
   ============================================================ */
window.App = (function(){
  const D = () => window.DB;

  // ---------- Helpers ----------
  const esc = s => String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const fmtMoney = v => 'R$ ' + Number(v||0).toLocaleString('pt-BR',{minimumFractionDigits:0,maximumFractionDigits:0});
  const fmtPct = v => Number(v||0).toLocaleString('pt-BR',{minimumFractionDigits:1}) + '%';
  const fmtDate = iso => iso ? new Date(iso).toLocaleDateString('pt-BR') : '—';
  const fmtDateShort = iso => iso ? new Date(iso).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'}) : '—';
  const fmtDateTime = iso => iso ? new Date(iso).toLocaleDateString('pt-BR')+' '+new Date(iso).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}) : '—';
  const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}) : '—';
  const initials = n => (n||'?').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
  const emp = id => D().employees.find(e=>e.id===id) || {name:'Sem responsável',color:'#94a3b8',role:'',dept:''};
  const statusClass = s => ({'Novo':'s-novo','Em atendimento':'s-em','Qualificado':'s-qual','Proposta enviada':'s-prop','Negociação':'s-neg','Convertido':'s-conv','Perdido':'s-perd','Cancelado':'s-canc'}[s]||'s-st');
  const priClass = p => ({'Baixa':'p-pri-baixa','Média':'p-pri-media','Alta':'p-pri-alta','Crítica':'p-pri-critica'}[p]||'p-pri-media');
  const ava = (name,color,cls) => `<span class="ava ${cls||'ava-md'}" style="background:${color||'#00a884'}">${initials(name)}</span>`;

  // ---------- State ----------
  const state = { view:'dashboard', period:'hoje', filters:{q:'',status:'',resp:'',pri:'',servico:'',date:''}, pager:{page:1}, calView:'month', calDate:new Date(), tplFilter:'Todos', settingsTab:'geral', analRange:'Últimos 30 dias' };

  // ---------- Toast ----------
  function toast(type,title,msg){ const wrap=document.getElementById('toast-wrap'); const el=document.createElement('div'); el.className='toast '+type;
    const ic={success:'✅',error:'⚠️',info:'ℹ️'}[type]||'✅';
    el.innerHTML=`<span class="tic">${ic}</span><div><div class="t-msg">${esc(title)}</div>${msg?`<div class="t-sub">${esc(msg)}</div>`:''}</div>`;
    wrap.appendChild(el); setTimeout(()=>{el.style.transition='opacity .3s';el.style.opacity='0';setTimeout(()=>el.remove(),300);},2800); }

  // ---------- Permissions ----------
  const can = perm => (D().permissions[D().currentUser.role]||[]).includes(perm);

  // ---------- Ícones SVG (estética refinada, sem emoji) ----------
  const svg=(inner,vb)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
  const ICON={
    dashboard:svg('<rect x="3" y="3" width="7" height="9" rx="1.6"/><rect x="14" y="3" width="7" height="5" rx="1.6"/><rect x="14" y="12" width="7" height="9" rx="1.6"/><rect x="3" y="16" width="7" height="5" rx="1.6"/>'),
    analytics:svg('<path d="M3 3v18h18"/><rect x="7" y="11" width="3" height="7" rx="1"/><rect x="12" y="7" width="3" height="11" rx="1"/><rect x="17" y="9" width="3" height="9" rx="1"/>'),
    reunioes:svg('<rect x="3" y="4.5" width="18" height="16" rx="2.5"/><path d="M8 2.5v4M16 2.5v4M3 9.5h18"/>'),
    leads:svg('<path d="M21 8a2 2 0 0 0-1-1.7l-7-3.8a2 2 0 0 0-1.9 0l-7 3.8A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 3.8a2 2 0 0 0 1.9 0l7-3.8a2 2 0 0 0 1-1.7z"/><path d="m3.3 7 8.7 4.7L20.7 7M12 22V11.7"/>'),
    perdidos:svg('<path d="M3 7l6 6 4-4 8 8"/><path d="M15 17h6v-6"/>'),
    templates:svg('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/>'),
    equipe:svg('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'),
    roteamento:svg('<circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M6 15V9a3 3 0 0 1 3-3h4"/><path d="m12 4 2 2-2 2"/><path d="M18 9v6a3 3 0 0 1-3 3h-4"/><path d="m12 20 2-2-2-2"/>'),
    config:svg('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3"/><path d="M1 14h6M9 8h6M17 16h6"/>'),
    bolt:svg('<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>'),
    flame:svg('<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.07-2.14-.22-4.05 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.15.43-2.29 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>'),
    target:svg('<circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="12" r="5.5"/><circle cx="12" cy="12" r="1.6"/>'),
    trend:svg('<path d="M3 7l6 6 4-4 8 8"/><path d="M15 17h6v-6"/>'),
    check:svg('<path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><path d="M22 4 12 14l-3-3"/>'),
    calendar:svg('<rect x="3" y="4.5" width="18" height="16" rx="2.5"/><path d="M8 2.5v4M16 2.5v4M3 9.5h18"/>'),
    arrows:svg('<path d="M7 17 17 7M8 7h9v9"/>'),
    money:svg('<path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/><path d="M16 12h4"/><circle cx="17" cy="12" r="1.2" fill="currentColor" stroke="none"/>'),
    clock:svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    doc:svg('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h6"/>'),
    inbox:svg('<path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M3 13h5l2 3h4l2-3h5"/>'),
    search:svg('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'),
    bell:svg('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>'),
    edit:svg('<path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>'),
    trash:svg('<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>')
  };

  // ---------- Navigation ----------
  const NAV_ITEMS = [
    {group:'Visão geral'},
    {key:'dashboard',label:'Dashboard',ic:'📊',perm:'dashboard'},
    {key:'analytics',label:'Analytics',ic:'📈',perm:'analytics'},
    {key:'reunioes',label:'Reuniões',ic:'📅',perm:'reunioes'},
    {group:'Atendimento'},
    {key:'leads',label:'Leads',ic:'🗂️',perm:'leads',badge:4},
    {key:'perdidos',label:'Leads Perdidos',ic:'📉',perm:'perdidos'},
    {key:'templates',label:'Respostas Automáticas',ic:'💬',perm:'templates'},
    {group:'Gestão'},
    {key:'equipe',label:'Equipe',ic:'👥',perm:'equipe'},
    {key:'roteamento',label:'Roteamento IA',ic:'🧠',perm:'roteamento'},
    {key:'config',label:'Configurações',ic:'⚙️',perm:'config'}
  ];
  const TITLES = {dashboard:['Dashboard','Visão geral dos atendimentos'],analytics:['Analytics','Desempenho e conversão'],reunioes:['Reuniões','Agenda de clientes'],leads:['Leads','Gestão de oportunidades'],perdidos:['Leads Perdidos','Análise de perdas'],templates:['Respostas Automáticas','Templates de resposta'],equipe:['Equipe','Atendimento e roteamento'],roteamento:['Roteamento IA','Regras inteligentes'],config:['Configurações','Ajustes da plataforma']};

  function buildSidebar(){
    const nav=document.getElementById('sidebar-nav'); let html='';
    NAV_ITEMS.forEach(it=>{
      if(it.group){ html+=`<div class="nav-group">${it.group}</div>`; return; }
      if(!can(it.perm)) return;
      const badge = it.badge?`<span class="badge">${it.badge}</span>`:'';
      html+=`<a class="nav-item ${state.view===it.key?'active':''}"${state.view===it.key?' aria-current="page"':''} onclick="App.nav('${it.key}')"><span class="ic">${ICON[it.key]||it.ic}</span>${it.label}${badge}</a>`;
    });
    nav.innerHTML=html;
  }
  function nav(key){
    if(!can((NAV_ITEMS.find(i=>i.key===key)||{}).perm||key)){ toast('error','Sem permissão','Você não tem acesso a essa área.'); return; }
    state.view=key; document.getElementById('sidebar').classList.remove('open'); buildSidebar(); render();
  }
  function setTitle(){ const t=TITLES[state.view]||['','']; document.getElementById('tb-title').textContent=t[0]; document.getElementById('tb-sub').textContent=t[1]; }

  // ---------- Render dispatcher ----------
  function render(){
    setTitle();
    const el=document.getElementById('app-content');
    const map={
      dashboard:renderDashboard, analytics:renderAnalytics, reunioes:renderMeetings,
      leads:renderLeads, perdidos:renderLost, templates:renderTemplates,
      equipe:renderTeam, roteamento:renderRouting, config:renderConfig
    };
    el.innerHTML=(map[state.view]||renderDashboard)();
    window.setTimeout(()=>drawCharts(state.view),50);
  }

  // ---------- Metrics ----------
  function metrics(){
    const L=D().leads, LL=D().lostLeads;
    const total=L.length+LL.length;
    const conv=L.filter(l=>l.status==='Convertido').length;
    const perd=L.filter(l=>l.status==='Perdido').length+LL.length;
    const novos=L.filter(l=>l.status==='Novo').length;
    const qual=L.filter(l=>['Qualificado','Proposta enviada','Negociação','Convertido'].includes(l.status)).length;
    const high=L.filter(l=>['Alta','Crítica'].includes(l.pri)).length;
    const pipe=L.filter(l=>['Qualificado','Proposta enviada','Negociação'].includes(l.status)).reduce((a,l)=>a+l.valor,0);
    const lostRev=LL.reduce((a,l)=>a+l.valor,0);
    const convRate=total?conv/total*100:0;
    const lossRate=perd/total*100;
    const withResp=L.filter(l=>l.tempoResp>0);
    const respAvg=withResp.length?withResp.reduce((a,l)=>a+l.tempoResp,0)/withResp.length:0;
    return {total,conv,perd,novos,qual,high,pipe,lostRev,convRate,lossRate,respAvg};
  }

  // ============================================================
  //  DASHBOARD
  // ============================================================
  const ACCENTS={'c-1':'#00a884','c-2':'#0ea5e9','c-3':'#10b981','c-4':'#f59e0b','c-5':'#ef4444','c-6':'#8b5cf6','c-7':'#14b8a6','c-8':'#0891b2','c-9':'#f43f5e'};
  const trend=(dir,txt)=>`<span class="ktrend ${dir}"><span class="t-arrow">${dir==='up'?'▲':dir==='down'?'▼':'•'}</span>${txt}</span>`;
  const kpi=(label,val,ick,color,tr)=>
    `<div class="card kpi" style="--acc:${ACCENTS[color]||'#00a884'}"><div class="kic ${color}">${ICON[ick]}</div><div class="kval">${val}</div><div class="klab">${label}</div>${tr||''}</div>`;

  // “hoje” virtual = data do lead mais recente (mantém a demo viva)
  function virtualNow(){ const d=D().leads.map(l=>new Date(l.entrada).getTime()); return d.length? new Date(Math.max(...d)) : new Date(); }
  function inWindow(iso,days){ return new Date(iso).getTime() >= virtualNow().getTime()-days*86400000; }
  const PERIODS={hoje:{d:1,label:'Hoje'},semana:{d:7,label:'7 dias'},mes:{d:30,label:'30 dias'}};

  // onboarding pós-login (dispensável via X)
  function onboardingCard(){
    let done=false; try{ done=!!localStorage.getItem('conectta-onboard'); }catch(e){}
    if(done) return '';
    const items=[['Cadastrar equipe',true],['Definir regras de roteamento',true],['Criar respostas automáticas',true],['Conectar WhatsApp',false],['Revisar prioridades',false],['Testar uma mensagem',false]];
    const pct=Math.round(items.filter(i=>i[1]).length/items.length*100);
    return `<div class="card on-card">
      <div class="onb-head"><div><div class="card-title">Configure sua Conectta.ai</div><div class="card-sub">${pct}% concluído · ${items.filter(i=>i[1]).length} de ${items.length} passos</div></div><button class="onb-x" onclick="App.dismissOnboarding()" aria-label="Fechar checklist">×</button></div>
      <div class="onb-prog"><div class="lfill" style="width:${pct}%"></div></div>
      <div class="onb-items">${items.map(i=>`<span class="${i[1]?'ok':''}">${i[1]?'✓':'·'} ${i[0]}</span>`).join('')}</div>
    </div>`;
  }
  function dismissOnboarding(){ try{ localStorage.setItem('conectta-onboard','1'); }catch(e){} toast('info','Checklist','Checklist de configuração concluída.'); render(); }

  function renderDashboard(){
    const M=metrics();
    const h=new Date().getHours();
    const saud = h<12?'Bom dia':h<18?'Boa tarde':'Boa noite';
    const novo=D().currentUser.name.split(' ')[0];
    const fNovo=M.novos, fQual=D().leads.filter(l=>l.status==='Qualificado').length, fProp=D().leads.filter(l=>l.status==='Proposta enviada').length, fNeg=D().leads.filter(l=>l.status==='Negociação').length, fConv=M.conv;
    const maxF=Math.max(fNovo,fQual,fProp,fNeg,fConv,1);
    const funnelRow=(v,label,color)=>`<div class="funnel-row"><div class="funnel-label">${label}</div><div class="funnel-track"><div class="funnel-fill" style="width:${Math.max(v/maxF*100,10)}%;background:${color}">${v}</div></div></div>`;
    const recent=[...D().leads].sort((a,b)=>new Date(b.entrada)-new Date(a.entrada)).slice(0,6);
    const urgent=[...D().leads].filter(l=>l.urgente||l.pri==='Crítica').slice(0,5);
    const p=PERIODS[state.period]||PERIODS.hoje;
    const winL=D().leads.filter(l=>inWindow(l.entrada,p.d));
    const winHigh=winL.filter(l=>['Alta','Crítica'].includes(l.pri)).length;
    const winConv=winL.filter(l=>l.status==='Convertido').length;
    const winRate=winL.length?winConv/winL.length*100:0;
    const winPerd=winL.filter(l=>l.status==='Perdido').length;

    return `
    ${onboardingCard()}
    <div class="page-head">
      <div><div class="greet">${saud}, ${novo}<span class="sub">Veja como seus atendimentos estão performando hoje.</span></div></div>
      <div class="page-head-actions">
        <div class="seg">${Object.entries(PERIODS).map(([k,v])=>`<button class="seg ${state.period===k?'on':''}" onclick="App.period('${k}')">${v.label}</button>`).join('')}</div>
        <span class="chip" style="background:var(--green-50);color:var(--green-600);border-color:#a7f3d0"><span class="dot" style="background:var(--green)"></span> Operando</span>
        <a class="btn btn-primary btn-sm" onclick="App.newLeadModal()">+ Novo lead</a>
      </div>
    </div>

    <div class="grid grid-4" style="margin-bottom:16px">
      ${kpi('Leads · '+p.label, winL.length,'bolt','c-1',trend('up','12% vs período anterior'))}
      ${kpi('Alta prioridade',winHigh,'flame','c-5',trend('neutral','precisam de ação'))}
      ${kpi('Conversão',fmtPct(winRate),'target','c-3',trend('up','3,2%'))}
      ${kpi('Leads perdidos',winPerd,'trend','c-4',trend('down','+2 no período'))}
    </div>

    <div class="grid dash-funnel-row" style="grid-template-columns:1.4fr 1fr;margin-bottom:16px;align-items:start">
      <div class="card card-pad">
        <div class="card-title">Funil de conversão</div><div class="card-sub">Do primeiro contato ao fechamento</div>
        ${funnelRow(fNovo,'Novos Leads','#0ea5e9')}
        ${funnelRow(fQual,'Qualificados','#8b5cf6')}
        ${funnelRow(fProp,'Proposta','#00a884')}
        ${funnelRow(fNeg,'Negociação','#14b8a6')}
        ${funnelRow(fConv,'Convertidos','#10b981')}
      </div>
      <div class="card card-pad">
        <div class="card-title">Precisa de atenção</div><div class="card-sub">Leads que exigem ação imediata</div>
        <div id="attn-list">${attentionList(urgent)}</div>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="card card-pad">
        <div class="card-title">Leads recentes</div><div class="card-sub">As conversas mais novas</div>
        ${miniLeads(recent)}
      </div>
      <div class="card card-pad">
        <div class="card-title">Pipeline estimado</div><div class="card-sub">Valor potencial em aberto</div>
        <div style="display:flex;gap:14px;align-items:center;margin-bottom:14px"><div style="font-size:30px;font-weight:800">${fmtMoney(M.pipe)}</div><span class="pill p-st">${M.qual} leads em aberto</span></div>
        <div class="load"><span>Receita realizada</span><div class="lbar"><div class="lfill" style="width:35%;background:var(--green)"></div></div><span>35%</span></div>
        <div class="load" style="margin-top:8px"><span>Em negociação</span><div class="lbar"><div class="lfill" style="width:${Math.min(Math.max(M.qual,5),100)}%;background:var(--brand)"></div></div><span>${M.qual} leads</span></div>
        <div class="tip-box" style="margin-top:16px"><b>Sugestão:</b> Priorize os ${M.high} leads de alta prioridade para maximizar a conversão este mês.</div>
      </div>
    </div>`;
  }

  function attentionList(leads){
    if(!leads.length) return `<div class="empty" style="padding:20px"><div class="eic">${ICON.check}</div><h4>Tudo em dia!</h4><p>Nenhum lead precisa de atenção.</p></div>`;
    return leads.map(l=>`<div style="display:flex;gap:12px;align-items:center;padding:11px 0;border-bottom:1px solid var(--border);cursor:pointer" onclick="App.openLead('${l.id}')">
      ${ava(l.nome,emp(l.respId).color,'ava-md')}
      <div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${l.nome}</div><div style="font-size:12px;color:var(--text-3)">${l.servico}</div></div>
      <span class="pill ${priClass(l.pri)}">${l.pri}</span></div>`).join('');
  }
  function miniLeads(leads){
    return `<div class="table-wrap"><table><thead><tr><th>Lead</th><th>Serviço</th><th>Status</th><th>Responsável</th></tr></thead><tbody>
      ${leads.map(l=>`<tr class="clickable" onclick="App.openLead('${l.id}')"><td><div class="cell-main">${l.nome}</div><div class="cell-sub">${l.empresa}</div></td><td>${l.servico}</td><td><span class="pill ${statusClass(l.status)}">${l.status}</span></td><td>${ava(emp(l.respId).name,emp(l.respId).color,'ava-sm')} ${emp(l.respId).name}</td></tr>`).join('')}
    </tbody></table></div>`;
  }

  // ============================================================
  //  LEAD DETAIL MODAL
  // ============================================================
  function aiReason(l){
    const map={'Novo orçamento':'O cliente demonstrou intenção explícita de contratar e perguntou sobre preço e prazo.','Proposta':'Cliente interessado, aguardando apresentação comercial.','Negociação':'Negociação ativa com possibilidade próxima de fechamento.','Reclamação':'Situação crítica que exige resolução imediata pela gerência.','Cancelamento':'Risco de perda do cliente — precisa retenção urgente.','Suporte':'Problema operacional ativo que exige resposta rápida.','Follow-up':'Cliente em decisão, precisa de acompanhamento.','Pergunta':'Solicitação simples de informação geral.'};
    return map[l.intencao]||'Análise automática com base em intenção, valor e urgência do lead.';
  }
  function detail(label,val){ return `<div><div style="font-size:11px;color:var(--text-3);font-weight:600">${label}</div><div style="font-weight:600;font-size:13px">${val}</div></div>`; }
  function openLead(id){
    const l=D().leads.find(x=>x.id===id); if(!l)return;
    const resp=emp(l.respId); const msgs=Array.isArray(l.msg)?l.msg:(l.msg?[l.msg]:[]);
    const tl=[
      {t:'Mensagem recebida',d:`${l.nome} iniciou a conversa`,when:fmtDate(l.entrada),cls:'done'},
      {t:'IA analisou a mensagem',d:`Intenção: ${l.intencao} · Serviço: ${l.servico}`,when:'automático',cls:'done'},
      {t:'Lead classificado',d:`Prioridade ${l.pri} · Valor ${l.valor?fmtMoney(l.valor):'—'}`,when:'automático',cls:'done'},
      l.respId?{t:'Roteado para '+resp.name,d:resp.role+' · '+resp.dept,when:'automático',cls:'done'}:{t:'Aguardando atribuição',d:'Lead novo ainda não roteado',when:'—',cls:'warn'},
      {t:'Primeira resposta em '+l.tempoResp+'h',d:l.status==='Convertido'?'Atendimento bem-sucedido':'Acompanhar para avançar',when:'',cls:l.status==='Convertido'?'done':'warn'}
    ];
    const modal=document.getElementById('modal');
    modal.className='modal modal-lg';
    modal.innerHTML=`
      <div class="modal-head"><h3>${l.nome} <span style="color:var(--text-3);font-weight:400">· ${l.id}</span></h3><button class="modal-x" onclick="App.closeModal()">×</button></div>
      <div class="modal-body">
        <div class="grid grid-2" style="margin-bottom:16px">
          <div class="card card-pad" style="box-shadow:none;background:var(--bg-soft)">
            <div style="display:flex;gap:14px;align-items:center;margin-bottom:14px">${ava(l.nome,resp.color,'ava-lg')}<div><div style="font-weight:700;font-size:17px">${l.nome}</div><div style="color:var(--text-3);font-size:13px">${l.empresa||'—'}</div></div></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
              ${detail('WhatsApp',l.whatsapp||'—')}${detail('Data de entrada',fmtDateTime(l.entrada))}${detail('Origem',l.origem||'—')}${detail('Valor estimado',l.valor?fmtMoney(l.valor):'—')}${detail('Prob. conversão',l.prob!=null?fmtPct(l.prob):'—')}${detail('Última interação',fmtDateTime(l.ultima))}
            </div>
          </div>
          <div class="ai-panel">
            <div class="ai-title">Análise do lead</div>
            <div class="ai-grid">
              <div class="ai-cell"><div class="l">Intenção</div><div class="v">${l.intencao}</div></div>
              <div class="ai-cell"><div class="l">Serviço</div><div class="v">${l.servico}</div></div>
              <div class="ai-cell"><div class="l">Prioridade</div><div class="v brand">${l.pri}</div></div>
              <div class="ai-cell"><div class="l">Potencial</div><div class="v">${l.valor>5000?'Alto':l.valor>2000?'Médio':'Baixo'}</div></div>
              <div class="ai-cell"><div class="l">Departamento</div><div class="v">${resp.dept||'—'}</div></div>
              <div class="ai-cell"><div class="l">Responsável sugerido</div><div class="v brand">${resp.name}</div></div>
            </div>
            <div class="ai-conf"><div class="val">${Math.min(99,Math.round((l.prob||60)+20))}%</div><div class="bar"><div class="bar-fill" style="width:${Math.min(99,(l.prob||60)+20)}%"></div></div><span style="font-size:12px;color:var(--text-3)">confiança</span></div>
            <div class="ai-reason"><b>Motivo:</b> ${aiReason(l)}</div>
          </div>
        </div>

        <div class="card card-pad" style="margin-bottom:16px">
          <div class="card-title">Histórico da conversa</div><div class="card-sub">Mensagens e análise da IA</div>
          <div style="display:flex;flex-direction:column;gap:10px">
            ${msgs.length?msgs.map(m=>`<div style="display:flex;gap:10px;align-items:flex-start"><span class="pill s-prop">WhatsApp</span><div style="background:var(--bg-soft);border:1px solid var(--border);border-radius:10px;padding:10px 13px;flex:1">${esc(m)}</div></div>`).join(''):`<div style="color:var(--text-3);font-size:13px">Sem mensagens registradas.</div>`}
          </div>
        </div>

        <div class="grid grid-2">
          <div class="card card-pad">
            <div class="card-title">Linha do tempo</div><div class="card-sub">Roteamento e atividades</div>
            <ul class="timeline">${tl.map(t=>`<li class="tl-item ${t.cls}"><div class="tl-t">${t.t}</div><div class="tl-d">${t.d}</div><div class="tl-when">${t.when}</div></li>`).join('')}</ul>
          </div>
          <div class="card card-pad">
            <div class="card-title">Ações</div><div class="card-sub">Gerencie este lead</div>
            <div style="display:flex;flex-direction:column;gap:10px">
              <label style="font-weight:600;font-size:13px">Status</label>
              <select style="padding:10px;border:1px solid var(--border-strong);border-radius:9px" onchange="App.changeLeadStatus('${l.id}',this.value)">${D().statuses.map(s=>`<option value="${s}" ${l.status===s?'selected':''}>${s}</option>`).join('')}</select>
              <label style="font-weight:600;font-size:13px">Responsável</label>
              <select style="padding:10px;border:1px solid var(--border-strong);border-radius:9px" onchange="App.changeLeadOwner('${l.id}',this.value)">${D().employees.filter(e=>e.active).map(e=>`<option value="${e.id}" ${l.respId===e.id?'selected':''}>${e.name} — ${e.role}</option>`).join('')}</select>
              <label style="font-weight:600;font-size:13px">Notas</label><textarea rows="2" style="padding:10px;border:1px solid var(--border-strong);border-radius:9px" placeholder="Adicionar nota…"></textarea>
              <div style="display:flex;gap:10px;flex-wrap:wrap"><a class="btn btn-secondary btn-sm" onclick="App.suggestResponse('${l.id}')">Sugerir resposta</a><a class="btn btn-danger btn-sm" onclick="App.markLost('${l.id}')">Marcar como perdido</a></div>
            </div>
          </div>
        </div>
      </div>`;
    document.getElementById('modal-bg').classList.add('show');
  }
  function closeModal(){ document.getElementById('modal-bg').classList.remove('show'); }
  function changeLeadStatus(id,s){
    const l=D().leads.find(x=>x.id===id); if(!l)return;
    l.status=s;
    if(s==='Perdido'){ D().lostLeads.push({nome:l.nome,empresa:l.empresa,valor:l.valor,motivo:'—',respId:l.respId,tempoResp:l.tempoResp,etapa:'Negociação',data:new Date().toISOString().slice(0,10)}); }
    toast('success','Status atualizado',`Lead marcado como "${s}".`); closeModal(); render();
  }
  function changeLeadOwner(id,oid){ const l=D().leads.find(x=>x.id===id); if(!l)return; l.respId=oid; toast('success','Lead reatribuído',`Agora com ${emp(oid).name}.`); openLead(id); }
  function markLost(id){ const l=D().leads.find(x=>x.id===id); if(!l)return; l.status='Perdido'; D().lostLeads.push({nome:l.nome,empresa:l.empresa,valor:l.valor,motivo:'Roteamento incorreto',respId:l.respId,tempoResp:l.tempoResp,etapa:l.status==='Negociação'?'Negociação':'Proposta',data:new Date().toISOString().slice(0,10)}); toast('success','Lead marcado como perdido','Registrado na análise de perdas.'); closeModal(); render(); }

  // ============================================================
  //  LEADS (CRM)
  // ============================================================
  function renderLeads(){
    const f=state.filters;
    let list=[...D().leads].sort((a,b)=>new Date(b.entrada)-new Date(a.entrada));
    if(f.q){const q=f.q.toLowerCase();list=list.filter(l=>(l.nome+' '+l.empresa+' '+l.whatsapp).toLowerCase().includes(q));}
    if(f.status)list=list.filter(l=>l.status===f.status);
    if(f.resp)list=list.filter(l=>l.respId===f.resp);
    if(f.pri)list=list.filter(l=>l.pri===f.pri);
    if(f.servico)list=list.filter(l=>l.servico===f.servico);
    if(f.date){const d=new Date(f.date).toDateString();list=list.filter(l=>new Date(l.entrada).toDateString()===d);}
    const per=8, totalPages=Math.max(1,Math.ceil(list.length/per));
    const page=Math.min(state.pager.page,totalPages); const rows=list.slice((page-1)*per,page*per);
    const opt=(arr,val,label)=>`<select onchange="App.filter('${val}',this.value)"><option value="">${label}</option>${arr.map(o=>`<option value="${o}" ${f[val]===o?'selected':''}>${o}</option>`).join('')}</select>`;
    const respSel=`<select onchange="App.filter('resp',this.value)"><option value="">Responsável: todos</option>${D().employees.filter(e=>e.active).map(e=>`<option value="${e.id}" ${f.resp===e.id?'selected':''}>${e.name}</option>`).join('')}</select>`;

    return `
    <div class="page-head"><div><div class="greet" style="font-size:22px">Leads</div><div class="sub">${list.length} leads · ${D().leads.filter(l=>l.status==='Convertido').length} convertidos</div></div>
      <div class="page-head-actions"><a class="btn btn-primary" onclick="App.newLeadModal()">+ Novo lead</a></div></div>
    <div class="card">
      <div class="toolbar">
        <div class="search-ic">${ICON.search}<input placeholder="Buscar nome, empresa, WhatsApp…" value="${esc(f.q)}" oninput="App.filter('q',this.value)"></div>
        <div class="field">${opt(D().statuses,'status','Status: todos')}</div>
        <div class="field">${respSel}</div>
        <div class="field">${opt(D().priorities,'pri','Prioridade: todas')}</div>
        <div class="field">${opt(D().services,'servico','Serviço: todos')}</div>
        <div class="field"><input type="date" value="${f.date||''}" onchange="App.filter('date',this.value)"></div>
        <div class="toolbar-spacer"></div><a class="btn btn-sm btn-secondary" onclick="App.clearFilters()">Limpar</a>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Lead</th><th>WhatsApp</th><th>Empresa</th><th>Data</th><th>Intenção</th><th>Serviço</th><th>Prioridade</th><th>Responsável</th><th>Status</th><th>Valor</th><th>Prob.</th><th>Últ. interação</th></tr></thead>
        <tbody>
        ${rows.length?rows.map(l=>`<tr class="clickable ${l.urgente?'status-row-urgent':''}" onclick="App.openLead('${l.id}')">
          <td><div class="cell-main">${l.nome}</div><div class="cell-sub">${l.id}</div></td><td>${l.whatsapp||'—'}</td><td>${l.empresa||'—'}</td><td>${fmtDate(l.entrada)}</td><td>${l.intencao}</td><td>${l.servico}</td>
          <td><span class="pill ${priClass(l.pri)}">${l.pri}</span></td><td>${l.respId?ava(emp(l.respId).name,emp(l.respId).color,'ava-sm')+' '+emp(l.respId).name:'—'}</td>
          <td><span class="pill ${statusClass(l.status)}">${l.status}</span></td><td>${l.valor?fmtMoney(l.valor):'—'}</td><td>${l.prob!=null?fmtPct(l.prob):'—'}</td><td>${fmtDateShort(l.ultima)}</td></tr>`).join('')
        :`<tr><td colspan="12"><div class="empty"><div class="eic">${ICON.leads}</div><h4>Nenhum lead encontrado</h4><p>Nenhum resultado para os filtros aplicados. Ajuste a busca.</p></div></td></tr>`}
        </tbody>
      </table></div>
      <div class="pager"><span class="info">Exibindo ${rows.length? (page-1)*per+1:0}–${Math.min(page*per,list.length)} de ${list.length}</span>${pagerButtons(page,totalPages)}</div>
    </div>`;
  }
  function pagerButtons(page,total){ let h=''; for(let i=1;i<=total;i++)h+=`<button class="${i===page?'active':''}" onclick="App.pagesGo(${i})">${i}</button>`; return `<button ${page<=1?'disabled':''} onclick="App.pagesGo(${page-1})">‹</button>${h}<button ${page>=total?'disabled':''} onclick="App.pagesGo(${page+1})">›</button>`; }
  function pagesGo(p){ state.pager.page=p; render(); }
  function filter(k,v){ state.filters[k]=v; state.pager.page=1; render(); }
  function clearFilters(){ state.filters={q:'',status:'',resp:'',pri:'',servico:'',date:''}; state.pager.page=1; render(); }

  // ============================================================
  //  LOST LEADS
  // ============================================================
  function renderLost(){
    const LL=D().lostLeads, lostRev=LL.reduce((a,l)=>a+l.valor,0);
    const mot={}; LL.forEach(l=>mot[l.motivo]=(mot[l.motivo]||0)+1);
    const etapa={}; LL.forEach(l=>etapa[l.etapa]=(etapa[l.etapa]||0)+1);
    const demora=LL.filter(l=>l.tempoResp>=15).length, rot=LL.filter(l=>l.motivo==='Roteamento incorreto').length;
    const neg=LL.filter(l=>l.etapa==='Negociação').length, prop=LL.filter(l=>l.etapa==='Proposta').length;
    return `
    <div class="page-head"><div><div class="greet" style="font-size:22px">Leads Perdidos</div><div class="sub">${LL.length} leads · ${fmtMoney(lostRev)} em receita estimada perdida</div></div>
      <div class="page-head-actions"><span class="pill p-pri-critica">Taxa de perda ${fmtPct(LL.length/(LL.length+D().leads.length)*100)}</span></div></div>
    <div class="grid grid-4" style="margin-bottom:16px">
      ${kpi('Leads perdidos',LL.length,'trend','c-4')}${kpi('Receita perdida',fmtMoney(lostRev),'money','c-5')}${kpi('Por resposta demorada',demora,'clock','c-4')}${kpi('Por roteamento incorreto',rot,'target','c-5')}
      ${kpi('Perdidos na negociação',neg,'arrows','c-4')}${kpi('Perdidos após proposta',prop,'doc','c-5')}
    </div>
    <div class="grid grid-2" style="margin-bottom:16px">
      <div class="card card-pad"><div class="card-title">Principais motivos de perda</div><div class="chart-box-sm"><canvas id="ch-motivos"></canvas></div></div>
      <div class="card card-pad"><div class="card-title">Perdas por etapa</div><div class="chart-box-sm"><canvas id="ch-etapa"></canvas></div></div>
    </div>
    <div class="card"><div class="card-pad" style="padding-bottom:8px"><div class="card-title">Registro de perdas</div><div class="card-sub">Detalhe de cada lead perdido</div></div>
      <div class="table-wrap"><table><thead><tr><th>Lead</th><th>Empresa</th><th>Valor</th><th>Motivo</th><th>Responsável</th><th>Tempo resposta</th><th>Etapa</th><th>Data</th></tr></thead><tbody>
      ${LL.map(l=>`<tr><td><div class="cell-main">${l.nome}</div></td><td>${l.empresa}</td><td>${fmtMoney(l.valor)}</td><td><span class="pill p-st">${l.motivo}</span></td><td>${ava(emp(l.respId).name,emp(l.respId).color,'ava-sm')} ${emp(l.respId).name}</td><td>${l.tempoResp}h</td><td>${l.etapa}</td><td>${fmtDate(l.data)}</td></tr>`).join('')}
      </tbody></table></div>
    </div>`;
  }

  // ============================================================
  //  MEETINGS
  // ============================================================
  const mStatusClass = m=>({'Agendada':'s-prop','Confirmada':'s-qual','Realizada':'s-conv','Reagendada':'s-em','Cancelada':'s-canc','Não compareceu':'s-perd'}[m]||'s-st');
  const tIco = t=>({'Apresentação de proposta':'📊','Sessão de descoberta':'🧭','Negociação de contrato':'🤝','Briefing de branding':'🎨','Negociação':'🤝','Sessão de escopo':'🗂️','Proposta':'💎','Descoberta':'🔍','Briefing visual':'🎨','Follow-up':'📝','Proposta comercial':'💼'}[t]||'📅');
  function calLabel(){ return state.calDate.toLocaleDateString('pt-BR',{month:'long',year:'numeric'}); }
  function calShift(d){ const n=new Date(state.calDate); if(state.calView==='month')n.setMonth(n.getMonth()+d); else if(state.calView==='week')n.setDate(n.getDate()+d*7); else n.setDate(n.getDate()+d); state.calDate=n; render(); }
  function calView(v){ state.calView=v; render(); }
  function evColor(s){ return {'Agendada':'#e0e7ff','Confirmada':'#a7f3d0','Realizada':'#a7f3d0','Não compareceu':'#fee2e2','Cancelada':'#e2e8f0','Reagendada':'#fef3c7'}[s]||'#e0e7ff'; }
  function renderCalendar(){
    const y=state.calDate.getFullYear(), mo=state.calDate.getMonth();
    const onDay=ds=>D().meetings.filter(m=>m.data&&m.data.slice(0,10)===ds);
    const iso=d=>{const x=new Date(d);x.setMinutes(x.getMinutes()-x.getTimezoneOffset());return x.toISOString().slice(0,10);};
    const cell=(d,other)=>`<div class="cal-day ${other?'other':''} ${d.toDateString()===new Date().toDateString()?'today':''}"><div class="num">${d.getDate()}</div><div class="cal-evs">${onDay(iso(d)).slice(0,3).map(m=>`<div class="cal-ev" style="background:${evColor(m.status)}">${fmtTime(m.data)} ${m.nome}</div>`).join('')}</div></div>`;
    if(state.calView==='month'){
      const first=new Date(y,mo,1); const start=new Date(first); start.setDate(1-((first.getDay()+6)%7));
      let h='<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px">'+['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'].map(d=>`<div class="cal-dow">${d}</div>`).join('')+'</div><div class="cal-grid">';
      for(let i=0;i<42;i++){ const d=new Date(start); d.setDate(start.getDate()+i); h+=cell(d,d.getMonth()!==mo); }
      return h+'</div>';
    }
    if(state.calView==='week'){
      const dow=(state.calDate.getDay()+6)%7, mon=new Date(state.calDate); mon.setDate(state.calDate.getDate()-dow);
      let h='<div class="cal-grid">'; for(let i=0;i<7;i++){ const d=new Date(mon); d.setDate(mon.getDate()+i); h+=cell(d,false); } return h+'</div>';
    }
    const ds=iso(state.calDate); const evs=D().meetings.filter(m=>m.data&&m.data.slice(0,10)===ds);
    return `<div class="empty" style="padding:30px"><div class="eic">${ICON.calendar}</div><h4>${state.calDate.toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'})}</h4>${evs.length?`<p style="margin-top:8px">${evs.map(m=>'· '+fmtTime(m.data)+' '+m.nome+' ('+m.tipo+')').join('<br>')}</p>`:`<p>Nenhuma reunião neste dia.</p>`}</div>`;
  }
  function renderMeetings(){
    const M=D().meetings;
    const upc=[...M].filter(m=>['Agendada','Confirmada'].includes(m.status)).sort((a,b)=>new Date(a.data)-new Date(b.data));
    const past=M.filter(m=>!['Agendada','Confirmada'].includes(m.status)).sort((a,b)=>new Date(b.data)-new Date(a.data));
    return `
    <div class="page-head"><div><div class="greet" style="font-size:22px">Reuniões</div><div class="sub">${upc.length} reuniões futuras</div></div>
      <div class="page-head-actions"><button class="btn btn-primary" onclick="App.newMeetingModal()">+ Nova reunião</button></div></div>
    <div class="card card-pad" style="margin-bottom:16px">
      <div class="cal-head">
        <button class="btn btn-sm btn-secondary" onclick="App.calShift(-1)">‹</button><div class="lbl">${calLabel()}</div>
        <div style="display:flex;gap:6px">
          <button class="btn btn-sm ${state.calView==='month'?'btn-primary':'btn-secondary'}" onclick="App.calView('month')">Mês</button>
          <button class="btn btn-sm ${state.calView==='week'?'btn-primary':'btn-secondary'}" onclick="App.calView('week')">Semana</button>
          <button class="btn btn-sm ${state.calView==='day'?'btn-primary':'btn-secondary'}" onclick="App.calView('day')">Dia</button>
          <button class="btn btn-sm btn-secondary" onclick="App.calShift(1)">›</button>
        </div>
      </div>
      <div>${renderCalendar()}</div>
    </div>
    <div class="grid grid-2">
      <div class="card card-pad"><div class="card-title">Próximas reuniões</div><div class="card-sub">Confirmações e agendamentos</div>
        ${upc.length?upc.map(m=>`<div style="display:flex;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);cursor:pointer" onclick="App.openMeeting('${m.id}')">${ava(m.nome,'#00a884','ava-md')}<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13.5px">${m.nome} <span style="color:var(--text-3)">· ${m.empresa}</span></div><div style="font-size:12px;color:var(--text-3)">${tIco(m.tipo)} ${m.tipo} · ${fmtDateShort(m.data)} · ${emp(m.empId).name}</div></div><span class="pill ${mStatusClass(m.status)}">${m.status}</span></div>`).join(''):`<div class="empty"><div class="eic">${ICON.calendar}</div><h4>Nenhuma reunião futura</h4></div>`}
      </div>
      <div class="card card-pad"><div class="card-title">Reuniões anteriores</div><div class="card-sub">Histórico e resultados</div>
        ${past.map(m=>`<div style="display:flex;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);cursor:pointer" onclick="App.openMeeting('${m.id}')"><div style="width:56px;text-align:center;color:var(--text-3);font-size:12px;font-weight:600">${fmtDateShort(m.data)}</div><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13.5px">${m.nome}</div><div style="font-size:12px;color:var(--text-3)">${tIco(m.tipo)} ${m.tipo} · ${emp(m.empId).name}</div></div><span class="pill ${mStatusClass(m.status)}">${m.status}</span></div>`).join('')}
      </div>
    </div>`;
  }
  function openMeeting(id){ const m=D().meetings.find(x=>x.id===id); if(!m)return; const modal=document.getElementById('modal'); modal.className='modal'; modal.innerHTML=`<div class="modal-head"><h3>${m.nome} — ${m.tipo}</h3><button class="modal-x" onclick="App.closeModal()">×</button></div><div class="modal-body"><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">${detail('Cliente',m.nome)}${detail('Empresa',m.empresa)}${detail('Responsável',emp(m.empId).name)}${detail('Data e hora',fmtDateTime(m.data))}${detail('Status',m.status)}${detail('Notas',m.nota||'—')}</div>${m.link?`<div style="margin-top:14px"><a class="btn btn-secondary btn-sm" href="${m.link}" target="_blank">Acessar link da reunião</a></div>`:''}</div><div class="modal-foot"><button class="btn btn-secondary" onclick="App.closeModal()">Fechar</button></div>`; document.getElementById('modal-bg').classList.add('show'); }
  function newMeetingModal(){ const modal=document.getElementById('modal'); modal.className='modal'; modal.innerHTML=`<div class="modal-head"><h3>Nova reunião</h3><button class="modal-x" onclick="App.closeModal()">×</button></div><div class="modal-body"><div class="row2"><div class="field"><label>Cliente</label><input placeholder="Nome do cliente"></div><div class="field"><label>Empresa</label><input placeholder="Empresa"></div></div><div class="row2"><div class="field"><label>Responsável</label><select>${D().employees.filter(e=>e.active).map(e=>`<option>${e.name} — ${e.role}</option>`).join('')}</select></div><div class="field"><label>Tipo</label><select><option>Apresentação de proposta</option><option>Sessão de descoberta</option><option>Negociação de contrato</option><option>Briefing de branding</option><option>Follow-up</option></select></div></div><div class="row2"><div class="field"><label>Data</label><input type="date"></div><div class="field"><label>Hora</label><input type="time"></div></div><div class="field"><label>Notas</label><textarea rows="2" placeholder="Observações…"></textarea></div></div><div class="modal-foot"><button class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button><button class="btn btn-primary" onclick="App.toast('success','Reunião criada com sucesso','Reunião adicionada à agenda.');App.closeModal()">Criar reunião</button></div>`; document.getElementById('modal-bg').classList.add('show'); }

  // ============================================================
  //  TEMPLATES
  // ============================================================
  function renderTemplates(){
    const cats=['Todos',...new Set(D().templates.map(t=>t.cat))];
    const list=state.tplFilter==='Todos'?D().templates:D().templates.filter(t=>t.cat===state.tplFilter);
    const hi=msg=>esc(msg).replace(/\{\{(\w+)\}\}/g,'<span class="var">{{$1}}</span>');
    return `
    <div class="page-head"><div><div class="greet" style="font-size:22px">Respostas Automáticas</div><div class="sub">${D().templates.length} templates</div></div><div class="page-head-actions"><button class="btn btn-primary" onclick="App.newTemplateModal()">+ Novo template</button></div></div>
    <div class="toolbar" style="border:none;padding-left:0">${cats.map(c=>`<span class="chip ${state.tplFilter===c?'brand':''}" onclick="App.tplFilter('${c}')">${c}</span>`).join('')}<div class="toolbar-spacer"></div><span style="font-size:12px;color:var(--text-3)">Variáveis: {{nome}} {{empresa}} {{servico}} {{responsavel}} {{data}} {{horario}}</span></div>
    <div class="tpl-grid">${list.map(t=>`
      <div class="tpl-card ${t.ativo===false?'tpl-off':''}">
        <div class="tcat">${t.cat}</div><div class="tt">${t.nome}</div>
        <div class="tmsg">${hi(t.msg)}</div>
        <div class="tfoot"><span class="chip ${t.ativo===false?'':'brand'}" onclick="App.toggleTpl('${t.id}')">${t.ativo===false?'● Inativo':'✓ Ativo'}</span>
        <div class="tacts"><button title="Editar" onclick="App.editTemplate('${t.id}')">${ICON.edit}</button><button title="Duplicar" onclick="App.dupTemplate('${t.id}')">⧉</button><button title="Excluir" onclick="App.delTemplate('${t.id}')">${ICON.trash}</button></div></div>
      </div>`).join('')}</div>`;
  }
  function tplFilter(c){ state.tplFilter=c; render(); }
  function toggleTpl(id){ const t=D().templates.find(x=>x.id===id); t.ativo=!t.ativo; toast('success','Template atualizado',t.ativo?'Template ativado.':'Template desativado.'); render(); }
  function dupTemplate(id){ const t=D().templates.find(x=>x.id===id); D().templates.push({...t,id:'t'+Date.now(),nome:t.nome+' (cópia)'}); toast('success','Template duplicado','Cópia criada.'); render(); }
  function delTemplate(id){ const i=D().templates.findIndex(x=>x.id===id); if(i>-1){D().templates.splice(i,1);toast('success','Template excluído','Removido com sucesso.');render();} }
  function templateModal(t){ const modal=document.getElementById('modal'); modal.className='modal';
    modal.innerHTML=`<div class="modal-head"><h3>${t?'Editar template':'Novo template'}</h3><button class="modal-x" onclick="App.closeModal()">×</button></div>
    <div class="modal-body"><div class="row2"><div class="field"><label>Categoria</label><select id="tpl-cat">${['Primeiro contato','Solicitação de orçamento','Site','Tráfego pago','Social media','Branding','Design','Reclamação','Cancelamento','Follow-up','Agendamento','Fora do horário','Atendimento geral'].map(c=>`<option ${t&&t.cat===c?'selected':''}>${c}</option>`).join('')}</select></div><div class="field"><label>Nome</label><input id="tpl-nome" value="${t?esc(t.nome):''}" placeholder="Ex.: Boas-vindas"></div></div>
    <div class="field"><label>Mensagem</label><textarea id="tpl-msg" rows="5" style="width:100%;padding:11px;border:1px solid var(--border-strong);border-radius:10px">${t?esc(t.msg):''}</textarea><div class="hint">Variáveis: {{nome}} {{empresa}} {{servico}} {{responsavel}} {{data}} {{horario}}</div></div></div>
    <div class="modal-foot"><button class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button><button class="btn btn-primary" onclick="App.saveTemplate('${t?t.id:''}')">Salvar template</button></div>`;
    document.getElementById('modal-bg').classList.add('show');
  }
  function newTemplateModal(){ templateModal(null); }
  function editTemplate(id){ templateModal(D().templates.find(x=>x.id===id)); }
  function saveTemplate(id){
    const cat=document.getElementById('tpl-cat').value, nome=document.getElementById('tpl-nome').value, msg=document.getElementById('tpl-msg').value;
    if(!nome||!msg){toast('error','Preencha os campos','Nome e mensagem são obrigatórios.');return;}
    if(id){const t=D().templates.find(x=>x.id===id);t.cat=cat;t.nome=nome;t.msg=msg;toast('success','Template salvo com sucesso','Alterações aplicadas.');}
    else{D().templates.push({id:'t'+Date.now(),cat,nome,msg});toast('success','Template criado','Novo template adicionado.');}
    closeModal(); render();
  }

  // ============================================================
  //  TEAM
  // ============================================================
  function renderTeam(){
    const team=D().employees.filter(e=>e.active); const all=D().leads;
    return `<div class="page-head"><div><div class="greet" style="font-size:22px">Equipe</div><div class="sub">${team.length} membros ativos</div></div><div class="page-head-actions"><button class="btn btn-primary" onclick="App.toast('info','Novo membro','Fluxo de convite em breve.')">+ Convidar membro</button></div></div>
    <div class="team-grid">${team.map(e=>{
      const leadsE=all.filter(l=>l.respId===e.id), conv=all.filter(l=>l.respId===e.id&&l.status==='Convertido').length, load=e.workload||0;
      const lc=load>70?'var(--red)':load>45?'var(--amber)':'var(--green)';
      return `<div class="team-card"><div class="tava" style="background:${e.color}">${initials(e.name)}</div>
      <div class="tn">${e.name}</div><div class="tr">${e.role} · ${e.dept}</div>
      <div class="status"><span class="dot" style="background:var(--green)"></span><span class="on">Ativo</span><span style="margin-left:auto;color:var(--text-3);font-size:12px">${e.seniority||'pleno'}</span></div>
      <div class="tstats"><div class="tstat"><div class="v">${leadsE.length}</div><div class="l">Leads atribuídos</div></div><div class="tstat"><div class="v">${e.convRate?fmtPct(e.convRate):'—'}</div><div class="l">Conversão</div></div><div class="tstat"><div class="v">${e.respAvg?e.respAvg+'h':'—'}</div><div class="l">Tempo resp.</div></div><div class="tstat"><div class="v">${conv}</div><div class="l">Convertidos</div></div></div>
      <div class="load" style="margin-top:12px"><span>Carga</span><div class="lbar"><div class="lfill" style="width:${load}%;background:${lc}"></div></div><span>${load}%</span></div>
      <div style="margin-top:12px;display:flex;gap:6px;flex-wrap:wrap">${(e.spec||[]).map(s=>`<span class="tag">${s}</span>`).join('')}</div></div>`;}).join('')}
    </div>`;
  }

  // ============================================================
  //  ROUTING
  // ============================================================
  function renderRouting(){
    const score=[['target','Intenção','peso 3'],['money','Valor do lead','peso 3'],['clock','Urgência','peso 2'],['doc','Complexidade','peso 2'],['equipe','Senioridade','peso 2'],['bolt','Carga atual','peso 1']];
    return `<div class="page-head"><div><div class="greet" style="font-size:22px">Roteamento IA</div><div class="sub">Defina quem recebe cada tipo de solicitação</div></div><div class="page-head-actions"><button class="btn btn-primary" onclick="App.newRuleModal()">+ Nova regra</button></div></div>
    <div class="card card-pad" style="margin-bottom:16px;background:linear-gradient(150deg,#eef2ff,#f5f3ff);border-color:var(--brand-100)">
      <div class="card-title">Como a IA decide para quem enviar</div><div class="card-sub">O roteador pondera os sinais abaixo para escolher o melhor destino.</div>
      <div class="row3" style="margin-top:8px">${score.map(s=>`<div class="ai-cell" style="text-align:center"><div class="score-ic">${ICON[s[0]]}</div><div style="font-weight:700;font-size:13px;margin-top:4px">${s[1]}</div><div style="font-size:11px;color:var(--text-3)">${s[2]}</div></div>`).join('')}</div>
    </div>
    <div class="card"><div class="card-pad" style="padding-bottom:8px"><div class="card-title">Regras ativas</div><div class="card-sub">A primeira regra correspondente é aplicada</div></div>
    ${D().rules.map(r=>`<div class="rule-item" style="margin:0 16px 10px"><div class="ric" style="background:var(--brand-50)">${r.ic}</div><div class="rmain"><div class="rt">${r.intent} → ${r.servico}</div><div class="rd">Prioridade: ${r.pri}</div></div><span class="rarrow">→</span><div class="rto">${r.to}</div><button class="btn btn-sm btn-secondary" onclick="App.editRule('${r.id}')">Editar</button></div>`).join('')}
    </div>`;
  }
  function ruleModal(r){
    const ints=['Venda','Orçamento','Reclamação','Cancelamento','Financeiro','Suporte','Pergunta geral','Lead alto valor','Reunião','Follow-up'];
    const sers=['Qualquer','Desenvolvimento de site','Tráfego pago','Branding / Design','Social media','Anúncios','Consultoria'];
    const modal=document.getElementById('modal'); modal.className='modal';
    modal.innerHTML=`<div class="modal-head"><h3>${r?'Editar regra':'Nova regra de roteamento'}</h3><button class="modal-x" onclick="App.closeModal()">×</button></div>
    <div class="modal-body"><div class="row2"><div class="field"><label>Tipo de solicitação (Intenção)</label><select id="rule-int">${ints.map(i=>`<option ${r&&r.intent===i?'selected':''}>${i}</option>`).join('')}</select></div><div class="field"><label>Serviço</label><select id="rule-serv">${sers.map(s=>`<option ${r&&r.servico===s?'selected':''}>${s}</option>`).join('')}</select></div></div>
    <div class="field"><label>Prioridade</label><select id="rule-pri">${D().priorities.map(p=>`<option ${r&&r.pri===p?'selected':''}>${p}</option>`).join('')}</select></div>
    <div class="field"><label>Encaminhar para</label><select id="rule-to">${D().employees.filter(e=>e.active).map(e=>`<option value="${e.id}" ${r&&r.toId===e.id?'selected':''}>${e.name} — ${e.role}</option>`).join('')}</select></div>
    <div class="demo-hint">Ex.: site de alto valor → vendedor sênior; reclamação → gerência.</div></div>
    <div class="modal-foot"><button class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button><button class="btn btn-primary" onclick="App.saveRule('${r?r.id:''}')">Salvar regra</button></div>`;
    document.getElementById('modal-bg').classList.add('show');
  }
  function newRuleModal(){ ruleModal(null); }
  function editRule(id){ ruleModal(D().rules.find(x=>x.id===id)); }
  function saveRule(id){
    const e=D().employees.find(x=>x.id===document.getElementById('rule-to').value);
    const data={intent:document.getElementById('rule-int').value,servico:document.getElementById('rule-serv').value,pri:document.getElementById('rule-pri').value,to:e.name+' — '+e.role,toId:e.id,ic:'🎯'};
    if(id){Object.assign(D().rules.find(x=>x.id===id),data);toast('success','Regra de roteamento atualizada','Alterações salvas.');}
    else{D().rules.push({id:'r'+Date.now(),...data});toast('success','Regra criada','Nova regra adicionada.');}
    closeModal(); render();
  }

  // ============================================================
  //  ANALYTICS
  // ============================================================
  function renderAnalytics(){
    const M=metrics();
    const ranges=['Hoje','Últimos 7 dias','Últimos 30 dias','Este mês','Últimos 3 meses','Personalizado'];
    return `<div class="page-head"><div><div class="greet" style="font-size:22px">Analytics</div><div class="sub">Acompanhe o desempenho dos atendimentos</div></div>
      <div class="page-head-actions"><select style="padding:9px;border:1px solid var(--border-strong);border-radius:9px;font-weight:600" onchange="App.analRange(this.value)">${ranges.map(r=>`<option ${state.analRange===r?'selected':''}>${r}</option>`).join('')}</select></div></div>
    <div class="grid grid-4" style="margin-bottom:16px">${kpi('Volume de leads',M.total,'inbox','c-2')}${kpi('Taxa de conversão',fmtPct(M.convRate),'target','c-3')}${kpi('Taxa de perda',fmtPct(M.lossRate),'trend','c-4')}${kpi('Tempo médio de resposta',M.respAvg.toFixed(1)+'h','clock','c-5')}</div>
    <div class="grid grid-2" style="margin-bottom:16px"><div class="card card-pad"><div class="card-title">Volume de leads ao longo do tempo</div><div class="chart-box"><canvas id="ch-volume"></canvas></div></div><div class="card card-pad"><div class="card-title">Funil de receita (pipeline)</div><div class="chart-box"><canvas id="ch-funil"></canvas></div></div></div>
    <div class="grid grid-2" style="margin-bottom:16px"><div class="card card-pad"><div class="card-title">Leads por serviço</div><div class="chart-box-sm"><canvas id="ch-servico"></canvas></div></div><div class="card card-pad"><div class="card-title">Leads por responsável</div><div class="chart-box-sm"><canvas id="ch-emp"></canvas></div></div></div>
    <div class="grid grid-2"><div class="card card-pad"><div class="card-title">Leads por intenção</div><div class="chart-box-sm"><canvas id="ch-intencao"></canvas></div></div><div class="card card-pad"><div class="card-title">Leads por prioridade</div><div class="chart-box-sm"><canvas id="ch-pri"></canvas></div></div></div>`;
  }
  function analRange(r){ state.analRange=r; render(); }
  function period(k){ state.period=k; render(); }

  // ============================================================
  //  CONFIG
  // ============================================================
  const CONFIG_NAV=[['geral','Geral'],['integracao','Integração WhatsApp'],['seguranca','Segurança'],['perfil','Meu perfil'],['notificacoes','Notificações'],['faturamento','Faturamento']];
  function renderConfig(){
    const t=state.settingsTab;
    const nav=CONFIG_NAV.map(([k,l])=>`<button class="${t===k?'active':''}" onclick="App.settingsTab('${k}')">${l}</button>`).join('');
    let body='';
    if(t==='geral') body=`<div class="card card-pad" style="margin-bottom:16px"><div class="card-title">Identidade da agência</div><div class="card-sub">Informações exibidas aos clientes</div>${configRow('Nome da agência','Agência Horizonte Digital')}${configRow('E-mail de contato','contato@horizonte.digital')}${configRow('WhatsApp principal','(11) 99999-0000')}${configRow('Fuso horário','America/Sao_Paulo (UTC-3)')}</div>
      <div class="card card-pad"><div class="card-title">Preferências</div><div class="card-sub">Comportamento padrão</div>${switchRow('Modo escuro','Tema escuro da interface',false)}${switchRow('Notificações por e-mail','Resumo diário do desempenho',true)}${switchRow('Resposta automática imediata','Templates respondem na chegada',true)}</div>`;
    else if(t==='integracao') body=`<div class="card card-pad" style="margin-bottom:16px"><div class="card-title">WhatsApp Business API</div><div class="card-sub">Conecte o número oficial da agência</div><div style="display:flex;gap:12px;align-items:center;margin-top:14px;flex-wrap:wrap"><span class="pill p-pri-critica">Status: Não conectado</span><span style="font-size:13px;color:var(--text-3)">Conecte a API oficial do WhatsApp Business para receber e processar mensagens em tempo real.</span></div><div class="demo-hint" style="margin-top:14px">Na versão de demonstração usamos dados simulados. A integração com a API oficial (Cloud API) será liberada sem redesenhar o produto.</div><div style="display:flex;gap:10px;margin-top:16px"><button class="btn btn-primary" onclick="App.toast('info','Integração','Conectando ao WhatsApp Business API…')">Conectar WhatsApp</button><button class="btn btn-secondary" onclick="App.toast('info','Teste','Testando conexão… (modo demonstração)')">Testar conexão</button></div></div><div class="card card-pad"><div class="card-title">Status da conexão</div>${configRow('WhatsApp','Não conectado (demonstração)')}${configRow('E-mail SMTP','Configurado')}${configRow('API Key','Ativa')}</div>`;
    if(t==='seguranca') body=`<div class="card card-pad"><div class="card-title">Permissões por função</div><div class="card-sub">O que cada perfil pode acessar</div>${Object.entries(D().permissions).map(([r,perms])=>`<div class="config-row"><div><div class="t">${r}</div><div class="d">${perms.map(p=>({dashboard:'Dashboard',leads:'Leads',perdidos:'Leads Perdidos',reunioes:'Reuniões',templates:'Templates',equipe:'Equipe',roteamento:'Roteamento',analytics:'Analytics',config:'Configurações'}[p])).join(' · ')}</div></div><span class="pill p-st">Acesso</span></div>`).join('')}</div>`;
    if(t==='perfil') body=`<div class="card card-pad"><div class="card-title">Meu perfil</div><div class="card-sub">${D().currentUser.email}</div><div style="display:flex;gap:16px;align-items:center;margin-bottom:20px">${ava(D().currentUser.name,'#00a884','ava-lg')}<div><div style="font-weight:700;font-size:16px">${D().currentUser.name}</div><div style="color:var(--text-3)">${D().currentUser.role}</div></div><button class="btn btn-sm btn-secondary" onclick="App.toast('info','Foto','Upload de foto em breve.')">Alterar foto</button></div><div class="row2"><div class="field"><label>Nome</label><input value="${D().currentUser.name}"></div><div class="field"><label>E-mail</label><input value="${D().currentUser.email}"></div></div><button class="btn btn-primary" onclick="App.toast('success','Perfil salvo','Informações atualizadas.')">Salvar alterações</button></div>`;
    if(t==='notificacoes') body=`<div class="card card-pad"><div class="card-title">Preferências de notificação</div><div class="card-sub">Escolha o que deseja receber</div>${configRow('Novo lead de alta prioridade','Notificado em tempo real')}${configRow('Lead sem resposta','Dispara após 4h sem retorno')}${configRow('Lead próximo de ser perdido','Alerta de risco')}${configRow('Nova reunião','Aviso ao ser agendada')}${configRow('Reclamação / cancelamento','Prioridade crítica')}</div>`;
    if(t==='faturamento') { const nb=new Date(); nb.setDate(1); nb.setMonth(nb.getMonth()+1); const billStr=nb.toLocaleDateString('pt-BR');
      body=`<div class="card card-pad" style="margin-bottom:16px"><div class="card-title">Plano atual</div><div class="card-sub">Assinatura mensal</div><div style="display:flex;align-items:center;gap:16px"><div style="font-size:32px;font-weight:800">R$ 450<span style="font-size:15px;color:var(--text-3)">/mês</span></div><span class="pill s-qual">Plano Base</span><span class="pill p-st">Modo demonstração</span></div><div style="margin-top:14px"><button class="btn btn-primary" onclick="App.toast('success','Assinatura ativa','Você está no Plano Base.')">Gerenciar assinatura</button></div></div><div class="card card-pad"><div class="card-title">Faturamento</div>${configRow('Próxima cobrança',billStr)}${configRow('Forma de pagamento','Cartão •••• 4242')}${configRow('Histórico','Ver faturas →')}</div>`;
    }
    return `<div class="page-head"><div><div class="greet" style="font-size:22px">Configurações</div><div class="sub">Gerencie sua operação</div></div></div><div class="settings-layout"><div class="settings-nav">${nav}</div><div>${body}</div></div>`;
  }
  function configRow(t,d){ return `<div class="config-row"><div><div class="t">${t}</div><div class="d">${d}</div></div></div>`; }
  function switchRow(t,d,on){ return `<div class="config-row"><div><div class="t">${t}</div><div class="d">${d}</div></div><label class="switch"><input type="checkbox" ${on?'checked':''} onchange="App.toast('info','Preferência','Configuração atualizada.')"><span class="slider"></span></label></div>`; }
  function settingsTab(k){ state.settingsTab=k; render(); }

  // ============================================================
  //  NEW LEAD + AI PREVIEW
  // ============================================================
  function analyze(msg){
    const m=(msg||'').toLowerCase();
    const r={intencao:'Pergunta',servico:'Consultoria',pri:'Baixa',valor:900,dept:'Atendimento',respId:'e6',conf:78};
    if(/cancelar|cancelamento/.test(m)){r.intencao='Cancelamento';r.servico='Contrato';r.pri='Crítica';r.valor=0;r.dept='Gerência';r.respId='e2';r.conf=96;}
    else if(/site|website|pagina|landing/.test(m)){r.intencao='Novo orçamento';r.servico='Desenvolvimento de site';r.pri=/\$|valor|custa|preço|quanto/.test(m)?'Alta':'Média';r.valor=/\$|valor|custa/.test(m)?8000:4500;r.dept='Vendas';r.respId='e3';r.conf=94;}
    else if(/tráfego|trafico|campanha|ads|anúncio/.test(m)){r.intencao='Novo orçamento';r.servico='Tráfego pago';r.pri='Alta';r.valor=4000;r.dept='Vendas';r.respId='e4';r.conf=92;}
    else if(/social|instagram|rede|conteúdo/.test(m)){r.intencao='Novo orçamento';r.servico='Social media';r.pri='Média';r.valor=2000;r.dept='Criativo';r.respId='e9';r.conf=88;}
    else if(/marca|branding|identidade|logo/.test(m)){r.intencao='Novo orçamento';r.servico='Branding';r.pri='Média';r.valor=3000;r.dept='Criativo';r.respId='e8';r.conf=89;}
    else if(/erro|problema|não está|quebrado|suporte/.test(m)){r.intencao='Suporte';r.servico='Suporte técnico';r.pri='Alta';r.valor=0;r.dept='Suporte';r.respId='e10';r.conf=93;}
    else if(/reclama|péssimo|ruim/.test(m)){r.intencao='Reclamação';r.servico='Qualquer';r.pri='Crítica';r.valor=0;r.dept='Vendas';r.respId='e2';r.conf=97;}
    else if(/reunião|reuniao|agenda|conversar/.test(m)){r.intencao='Reunião';r.servico='Qualquer';r.pri='Média';r.valor=0;r.dept='Vendas';r.respId='e2';r.conf=82;}
    else if(/quanto|valor|custa|preço/.test(m)){r.intencao='Orçamento';r.servico='Consultoria';r.pri='Média';r.valor=1500;r.dept='Vendas';r.respId='e4';r.conf=84;}
    return r;
  }
  function newLeadModal(){
    const modal=document.getElementById('modal'); modal.className='modal modal-lg';
    modal.innerHTML=`<div class="modal-head"><h3>Novo lead</h3><button class="modal-x" onclick="App.closeModal()">×</button></div>
    <div class="modal-body"><div class="demo-hint" style="margin-bottom:16px"><b>Simular mensagem recebida:</b> digite a mensagem do cliente e veja a IA analisar, classificar e sugerir o responsável.</div>
    <div class="field"><label>Mensagem do cliente (WhatsApp)</label><textarea id="nl-msg" rows="3" style="width:100%;padding:11px;border:1px solid var(--border-strong);border-radius:10px" placeholder="Ex.: Olá, preciso de um site profissional. Quanto custa?" oninput="App.previewLead()"></textarea></div>
    <div class="row2"><div class="field"><label>Nome do cliente</label><input id="nl-nome" placeholder="Nome completo"></div><div class="field"><label>WhatsApp</label><input id="nl-ws" placeholder="(11) 90000-0000"></div></div>
    <div class="row2"><div class="field"><label>Empresa</label><input id="nl-emp" placeholder="Nome da empresa"></div><div class="field"><label>Origem</label><select id="nl-orig"><option>WhatsApp</option><option>Instagram</option><option>Facebook</option><option>Site</option><option>Indicação</option></select></div></div>
    <div class="card" style="padding:14px;background:var(--bg-soft);margin-top:6px"><div class="card-title" style="font-size:13px">Classificação automática</div><div id="nl-ai" style="font-size:13px;color:var(--text-3);margin-top:6px">Digite a mensagem para ver a classificação automática…</div></div></div>
    <div class="modal-foot"><button class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button><button class="btn btn-primary" onclick="App.saveNewLead()">Registrar lead</button></div>`;
    document.getElementById('modal-bg').classList.add('show');
  }
  async function landingDemo(){
    const t=document.getElementById('ld-msg'); const box=document.getElementById('ld-result'); if(!t||!box)return;
    const msg=t.value.trim();
    if(msg.length<3){ box.innerHTML=`<div class="hint">Digite uma mensagem de cliente para analisar.</div>`; return; }
    const r = Services && Services.config.remote ? await Services.ai.classify(msg) : analyze(msg);
    const rc=emp(r.respId);
    const priColor=r.pri==='Crítica'?'#f43f5e':r.pri==='Alta'?'#ef4444':r.pri==='Média'?'#f59e0b':'#0ea5e9';
    box.innerHTML=`<div class="ld-head">Classificação automática <span class="pill p-st">modo demonstração</span></div>
      <div class="ld-grid">
        <div class="ld-cell"><span>Intenção</span><b>${esc(r.intencao)}</b></div>
        <div class="ld-cell"><span>Serviço</span><b>${esc(r.servico)}</b></div>
        <div class="ld-cell"><span>Prioridade</span><b style="color:${priColor}">${esc(r.pri)}</b></div>
        <div class="ld-cell"><span>Valor estimado</span><b>${fmtMoney(r.valor)}</b></div>
        <div class="ld-cell"><span>Departamento</span><b>${esc(r.dept)}</b></div>
        <div class="ld-cell"><span>Responsável sugerido</span><b>${esc(rc.name)} — ${esc(rc.role)}</b></div>
      </div>
      <div class="ld-foot">Confiança da análise: <b>${r.conf}%</b> · Lead encaminhado para <b>${esc(rc.name)}</b></div>`;
  }

  async function previewLead(){
    const msg=document.getElementById('nl-msg').value; const box=document.getElementById('nl-ai'); if(!box)return;
    // Em produção: Services.ai.classify chama a API de IA; no mock usa a heurística local.
    const r= Services && Services.config.remote ? await Services.ai.classify(msg) : analyze(msg);
    const col=r.pri==='Alta'||r.pri==='Crítica'?'red':'brand';
    box.innerHTML=`<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:6px">
      <div><div style="font-size:11px;color:var(--text-3)">Intenção</div><b>${r.intencao}</b></div><div><div style="font-size:11px;color:var(--text-3)">Serviço</div><b>${r.servico}</b></div><div><div style="font-size:11px;color:var(--text-3)">Prioridade</div><b style="color:var(--${col})">${r.pri}</b></div>
      <div><div style="font-size:11px;color:var(--text-3)">Valor estimado</div><b>${fmtMoney(r.valor)}</b></div><div><div style="font-size:11px;color:var(--text-3)">Departamento</div><b>${r.dept}</b></div><div><div style="font-size:11px;color:var(--text-3)">Responsável</div><b style="color:var(--brand)">${emp(r.respId).name}</b></div>
    </div><div style="margin-top:8px;font-size:12px;color:var(--text-3)">Confiança da análise: <b>${r.conf}%</b></div>`;
  }
  async function saveNewLead(){
    const nome=document.getElementById('nl-nome').value, msg=document.getElementById('nl-msg').value;
    if(!nome||!msg){toast('error','Preencha os dados','Nome e mensagem são obrigatórios.');return;}
    const r=analyze(msg); const id='L-'+Math.floor(1000+Math.random()*9000);
    const lead={id,nome,empresa:document.getElementById('nl-emp').value||'—',whatsapp:document.getElementById('nl-ws').value||'—',entrada:new Date().toISOString(),origem:document.getElementById('nl-orig').value,intencao:r.intencao,servico:r.servico,pri:r.pri,respId:r.respId,status:'Novo',valor:r.valor,ultima:new Date().toISOString(),tempoResp:0,prob:50,urgente:r.pri==='Crítica',msg:[msg]};
    await Services.leads.create(lead); // persiste via camada de API (mock hoje)
    if (Services.config.remote && lead.whatsapp) {
      await Services.whatsapp.sendTemplate({ to: lead.whatsapp, templateId: 't1', variables: { nome, servico: lead.servico, responsavel: emp(r.respId).name } });
    }
    toast('success','Lead registrado com sucesso',`${nome} roteado para ${emp(r.respId).name} (${r.pri}).`); closeModal(); render();
  }

  async function suggestResponse(id){
    const l=D().leads.find(x=>x.id===id); if(!l)return;
    const tpl=D().templates.find(t=>t.id==='t1')||D().templates[0];
    const text=Services.templates.render(tpl.msg,{nome:l.nome,empresa:l.empresa,servico:l.servico,responsavel:emp(l.respId).name});
    const res=await Services.whatsapp.sendText({ to:l.whatsapp, text });
    toast('success','Resposta sugerida',`Mensagem a partir de "${tpl.nome}".`+(res&&res.mock?' (modo demonstração)':' Enviada.'));
  }

  // ============================================================
  //  Notifications & misc UI
  // ============================================================
  function renderNtf(){
    const list=document.getElementById('ntf-list'); const n=D().notifications;
    document.getElementById('ntf-count').textContent=n.filter(x=>x.unread).length;
    list.innerHTML=n.length?n.map((x,i)=>`<div class="ntf-item ${x.unread?'unread':''}" onclick="App.showNtf(${i})"><div class="nic" style="background:${x.color}">${x.ic}</div><div style="flex:1;min-width:0"><div class="t">${esc(x.t)}</div><div class="d">${esc(x.d)}</div></div><div class="when">${x.when}</div></div>`).join(''):`<div class="ntf-empty">Nenhuma notificação</div>`;
  }
  function toggleNtf(){ document.getElementById('ntf-panel').classList.toggle('show'); }
  function showNtf(i){ const x=D().notifications[i]; if(!x)return; x.unread=false; renderNtf(); toast('info',x.t,x.d); }
  function clearNtf(){ D().notifications.forEach(n=>n.unread=false); renderNtf(); toast('info','Notificações','Todas marcadas como lidas.'); }
  function toggleSidebar(){ const sb=document.getElementById('sidebar'); const open=sb.classList.toggle('open'); const scrim=document.getElementById('sidebar-scrim'); if(scrim)scrim.classList.toggle('show',open); const mb=document.querySelector('.menu-btn'); if(mb)mb.setAttribute('aria-expanded',open?'true':'false'); }
  function globalSearch(q){ if(q&&q.length>2){ state.filters.q=q; state.view='leads'; buildSidebar(); render(); } }
  function openProfile(){ toast('info',D().currentUser.name,D().currentUser.role+' · '+D().currentUser.email); }

  // ============================================================
  //  CHART DRAWING (Chart.js via CDN)
  // ============================================================
  let charts={};
  function drawCharts(view){
    Object.values(charts).forEach(c=>{try{c.destroy()}catch(e){}}); charts={};
    if(typeof Chart==='undefined')return;
    const PAL=['#00a884','#0ea5e9','#10b981','#f59e0b','#8b5cf6','#f43f5e','#14b8a6','#a855f7'];
    Chart.defaults.font.family="'Inter',sans-serif"; Chart.defaults.color='#64748b'; Chart.defaults.borderColor='#eef0f6';
    const C=id=>document.getElementById(id);
    if(view==='perdidos'){
      const mot={};D().lostLeads.forEach(l=>mot[l.motivo]=(mot[l.motivo]||0)+1);
      if(C('ch-motivos'))charts.motivos=new Chart(C('ch-motivos'),{type:'doughnut',data:{labels:Object.keys(mot),datasets:[{data:Object.values(mot),backgroundColor:PAL}]},options:{cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:12}}}}});
      const eta={};D().lostLeads.forEach(l=>eta[l.etapa]=(eta[l.etapa]||0)+1);
      if(C('ch-etapa'))charts.etapa=new Chart(C('ch-etapa'),{type:'bar',data:{labels:Object.keys(eta),datasets:[{data:Object.values(eta),backgroundColor:PAL}]},options:{indexAxis:'y',plugins:{legend:{display:false}}}});
    }
    if(view==='analytics'){
      if(C('ch-volume'))charts.vol=new Chart(C('ch-volume'),{type:'line',data:{labels:['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],datasets:[{label:'Leads',data:[18,24,15,28,21,9,6],borderColor:'#00a884',backgroundColor:'rgba(0,168,132,.12)',fill:true,tension:.4,pointRadius:3,pointBackgroundColor:'#00a884'}]},options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
      if(C('ch-funil'))charts.funil=new Chart(C('ch-funil'),{type:'bar',data:{labels:['Novos','Qualificados','Proposta','Negociação','Convertidos'],datasets:[{data:[32,18,12,8,5],backgroundColor:['#0ea5e9','#8b5cf6','#00a884','#14b8a6','#10b981'],borderRadius:6}]},options:{plugins:{legend:{display:false}}}});
      const sCount={};D().leads.forEach(l=>sCount[l.servico]=(sCount[l.servico]||0)+1);
      if(C('ch-servico'))charts.s=new Chart(C('ch-servico'),{type:'doughnut',data:{labels:Object.keys(sCount),datasets:[{data:Object.values(sCount),backgroundColor:PAL}]},options:{cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:12}}}}});
      const eCount={};D().leads.filter(l=>l.respId).forEach(l=>{const n=emp(l.respId).name;eCount[n]=(eCount[n]||0)+1});
      if(C('ch-emp'))charts.emp=new Chart(C('ch-emp'),{type:'bar',data:{labels:Object.keys(eCount),datasets:[{data:Object.values(eCount),backgroundColor:'#0ea5e9',borderRadius:6}]},options:{indexAxis:'y',plugins:{legend:{display:false}}}});
      const iCount={};D().leads.forEach(l=>iCount[l.intencao]=(iCount[l.intencao]||0)+1);
      if(C('ch-intencao'))charts.int=new Chart(C('ch-intencao'),{type:'polarArea',data:{labels:Object.keys(iCount),datasets:[{data:Object.values(iCount),backgroundColor:PAL}]},options:{plugins:{legend:{position:'bottom',labels:{boxWidth:12}}}}});
      const pCount={};D().leads.forEach(l=>pCount[l.pri]=(pCount[l.pri]||0)+1);
      if(C('ch-pri'))charts.pri=new Chart(C('ch-pri'),{type:'bar',data:{labels:Object.keys(pCount),datasets:[{data:Object.values(pCount),backgroundColor:['#0ea5e9','#f59e0b','#ef4444','#f43f5e'],borderRadius:6}]},options:{plugins:{legend:{display:false}}}});
    }
  }

  // ============================================================
  //  Login
  // ============================================================
  function authTab(k){
    const li=document.getElementById('auth-login'), ri=document.getElementById('auth-register');
    const lb=document.getElementById('atab-login'), rb=document.getElementById('atab-reg');
    if(li)li.style.display=k==='login'?'':'none';
    if(ri)ri.style.display=k==='register'?'':'none';
    if(lb)lb.classList.toggle('active',k==='login');
    if(rb)rb.classList.toggle('active',k==='register');
  }
  function togglePass(){ const p=document.getElementById('auth-pass'); if(p) p.type=p.type==='password'?'text':'password'; }
  function forgotPass(){ toast('info','Redefinição de senha','Em modo demonstração, enviamos um link fictício de redefinição para o seu e-mail.'); }
  function finishOnboarding(){
    const nome=document.getElementById('rg-nome'); const emp=document.getElementById('rg-empresa');
    if(!nome || !nome.value.trim() || !emp || !emp.value.trim()){ toast('error','Preencha os campos','Nome e nome da empresa são obrigatórios.'); return; }
    toast('success','Conta criada em modo demonstração','Vamos configurar sua operação. Bem-vindo à Conectta.ai!');
    setTimeout(enterApp, 700);
  }
  function enterApp(){
    document.getElementById('view-landing').style.display='none';
    document.getElementById('view-auth').style.display='none';
    document.getElementById('view-app').style.display='flex';
    document.getElementById('side-name').textContent=D().currentUser.name;
    document.getElementById('side-role').textContent=D().currentUser.role;
    document.getElementById('side-ava').textContent=initials(D().currentUser.name);
    document.getElementById('top-ava').textContent=initials(D().currentUser.name);
    buildSidebar(); render();
  }

  // ---------- init ----------
  // ---------- Tema (claro/escuro) ----------
  const THEME_ICON = {
    dark:  '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
    light: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>'
  };
  function currentTheme(){ const d=document.documentElement; return (d&&d.getAttribute('data-theme'))==='dark'?'dark':'light'; }
  function renderThemeBtn(){
    const b=document.getElementById('themeToggle'); if(!b) return;
    b.innerHTML=THEME_ICON[currentTheme()];
  }
  function toggleTheme(){
    const next=currentTheme()==='dark'?'light':'dark';
    const d=document.documentElement; if(d) d.setAttribute('data-theme',next);
    try{ localStorage.setItem('conectta-theme',next); }catch(e){}
    renderThemeBtn();
    toast('info','Tema',next==='dark'?'Modo escuro ativado.':'Modo claro ativado.');
  }

  function init(){
    const yr=document.getElementById('copy-year'); if(yr) yr.textContent=new Date().getFullYear();
    window.setLD=function(v){ const t=document.getElementById('ld-msg'); if(t){ t.value=v; App.landingDemo(); } };
    renderNtf();
    renderThemeBtn();
    document.querySelectorAll('.faq-q').forEach(b=>b.addEventListener('click',()=>{b.parentElement.classList.toggle('open');}));
    const pass=document.getElementById('auth-pass'); if(pass)pass.addEventListener('keydown',e=>{if(e.key==='Enter')enterApp();});
    const email=document.getElementById('auth-email'); if(email)email.addEventListener('keydown',e=>{if(e.key==='Enter')enterApp();});
  }

  // ---------- Public API ----------
  return {
    enterApp, nav, buildSidebar, render, init,
    toast, closeModal,
    openLead, markLost, changeLeadStatus, changeLeadOwner,
    newLeadModal, previewLead, saveNewLead, suggestResponse, landingDemo,
    newMeetingModal, openMeeting, calShift, calView,
    tplFilter, toggleTpl, dupTemplate, delTemplate, newTemplateModal, editTemplate, saveTemplate,
    newRuleModal, editRule, saveRule,
    settingsTab, analRange, period,
    filter, clearFilters, pagesGo,
    toggleNtf, clearNtf, showNtf, renderNtf, toggleSidebar, globalSearch, openProfile,
    authTab, togglePass, forgotPass, finishOnboarding, dismissOnboarding,
    toggleTheme
  };
})();

document.addEventListener('DOMContentLoaded', App.init);