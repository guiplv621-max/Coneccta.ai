/* ============================================================
   CONECTTA.AI — Services (camada de API)
   ------------------------------------------------------------
   Ponto ÚNICO de integração com backends (WhatsApp Business API
   e API de IA). Toda chamada externa passa por aqui.

   Estado atual: `config.remote = false` → usa mock local, então
   o app funciona 100% sem backend.
   Para ir a produção: preencha os endpoints, autentique e mude
   `config.remote = true`. Nenhuma outra parte do frontend muda.
   ============================================================ */
window.Services = (() => {

  // ---------- Configuração (preencha para ir a produção) ----------
  const config = {
    remote: false,
    whatsapp: {
      baseUrl: '',            // ex.: 'https://graph.facebook.com/v19.0/PHONE_ID'
      phoneNumber: '',
      accessToken: ''         // segredo — nunca no código-fonte em produção
    },
    ai: {
      baseUrl: '',            // ex.: 'https://api.sua-ia.com'
      model: ''
    },
    api: {
      baseUrl: ''             // ex.: 'https://api.coneccta.ai/v1'
    }
  };

  const db = () => window.DB;

  // ---------- HTTP helper (fetch) ----------
  async function http(path, { method = 'GET', body = null, headers = {} } = {}) {
    const res = await fetch(path, {
      method,
      headers: { 'Content-Type': 'application/json', ...headers },
      body: body ? JSON.stringify(body) : null
    });
    if (!res.ok) throw new Error(`Falha na requisição (${res.status})`);
    return res.json();
  }

  // ============================================================
  //  WHATSAPP — envio de mensagens e canal de entrada
  // ============================================================
  const whatsapp = {

    /** Envia uma mensagem de texto simples para um cliente. */
    async sendText({ to, text }) {
      if (!config.remote) {
        console.info('[Services] Envio (mock):', to, '→', text);
        return { ok: true, mock: true, to, text, sentAt: new Date().toISOString() };
      }
      return await http(`${config.whatsapp.baseUrl}/messages`, {
        method: 'POST',
        body: { to, text },
        headers: { Authorization: `Bearer ${config.whatsapp.accessToken}` }
      });
    },

    /** Envia uma mensagem a partir de um template de resposta automática. */
    async sendTemplate({ to, templateId, variables = {} }) {
      const tpl = db().templates.find(t => t.id === templateId);
      const text = templates.render(tpl ? tpl.msg : '', variables);
      return this.sendMessage({ to, text });
    },

    /**
     * Canal de MENSAGENS RECEBIDAS (webhook / websocket).
     * Em produção, ligue aqui ao webhook da Cloud API do WhatsApp:
     *   - receba o payload, extraia `from` + `text`
     *   - chame `Services.ai.classify({ message: text })`
     *   - chame `Services.leads.create(...)` / roteie
     * Ex.: socket.on('message', handler)  ou  webhook POST.
     */
    onMessage(handler) {
      console.info('[Services.whatsapp] Canal de mensagens recebidas registrado (mock).');
      // TODO(prod): config.remote && webhook/websocket real
      return { unsubscribe() {} };
    }
  };

  // ============================================================
  //  IA — classificação de intenção e roteamento
  // ============================================================

  /**
   * Classifica uma mensagem recebida: intenção, serviço, prioridade,
   * valor estimado, departamento e responsável sugerido + confiança.
   * Na produção, chama o endpoint de IA; hoje usa heurística local.
   */
  async function classify(message) {
    if (config.remote) {
      return await http(`${config.ai.baseUrl}/classify`, { method: 'POST', body: { message } });
    }
    return localClassify(message || '');
  }

  /**
   * Roteia um lead já classificado para a regra/indivíduo adequado.
   */
  async function route({ classification, leadId } = {}) {
    if (config.remote) {
      return await http(`${config.ai.baseUrl}/route`, { method: 'POST', body: { classification, leadId } });
    }
    return localRoute(classification);
  }

  // ============================================================
  //  LEADS / CRM
  // ============================================================
  const leads = {
    /** Lista os leads (mock: retorna do banco local). */
    async list(filters = {}) {
      if (!config.remote) return db().leads;
      return await http(`${config.api.baseUrl}/leads?` + new URLSearchParams(filters));
    },

    /** Cria um novo lead a partir de um atendimento de WhatsApp. */
    async create(lead) {
      if (!config.remote) {
        db().leads.unshift(lead);
        return { ok: true, mock: true, id: lead.id };
      }
      return await http(`${config.api.baseUrl}/leads`, { method: 'POST', body: lead });
    },

    /** Atualiza campos de um lead. */
    async update(id, patch) {
      if (!config.remote) {
        Object.assign(db().leads.find(l => l.id === id) || {}, patch);
        return { ok: true, mock: true };
      }
      return await http(`${config.api.baseUrl}/leads/${id}`, { method: 'PATCH', body: patch });
    },

    /** Altera o status (inclui mover para perdido). */
    async updateStatus(id, status) {
      if (!config.remote) {
        const lead = db().leads.find(l => l.id === id);
        if (lead) lead.status = status;
        return { ok: true, mock: true };
      }
      return await http(`${config.api.baseUrl}/leads/${id}/status`, { method: 'PATCH', body: { status } });
    },

    /** Atribui/reatribui o responsável de um lead. */
    async assign(id, employeeId) {
      if (!config.remote) {
        const lead = db().leads.find(l => l.id === id);
        if (lead) lead.respId = employeeId;
        return { ok: true, mock: true };
      }
      return await http(`${config.api.baseUrl}/leads/${id}/assign`, { method: 'PATCH', body: { employeeId } });
    }
  };

  // ============================================================
  //  REUNIÕES
  // ============================================================
  const meetings = {
    async create(meeting) {
      if (!config.remote) {
        db().meetings.unshift(meeting);
        return { ok: true, mock: true, id: meeting.id };
      }
      return await http(`${config.api.baseUrl}/meetings`, { method: 'POST', body: meeting });
    }
  };

  // ============================================================
  //  TEMPLATES DE RESPOSTA
  // ============================================================
  const templates = {
    /** Substitui variáveis {{nome}}/{{servico}}/... em uma mensagem. */
    render(text, vars = {}) {
      return String(text || '').replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] != null ? vars[k] : `{{${k}}}`);
    }
  };

  // ============================================================
  //  FALLBACK LOCAL (heurísticas) — espelha a lógica atual
  // ============================================================
  function localClassify(message) {
    const m = (message || '').toLowerCase();
    const r = { intent: 'Pergunta', intencao: 'Pergunta', service: 'Consultoria', servico: 'Consultoria',
                pri: 'Baixa', value: 900, valor: 900, dept: 'Atendimento', department: 'Atendimento',
                respId: 'e6', confidence: 78, conf: 78 };
    if (/cancelar|cancelamento/.test(m)) return { ...r, intencao: 'Cancelamento', pri: 'Crítica', valor: 0, dept: 'Gerência', respId: 'e2', conf: 96 };
    if (/site|website|pagina|landing/.test(m)) {
      const expensive = /\$|valor|custa|preço|quanto/.test(m);
      return { ...r, intencao: 'Novo orçamento', servico: 'Desenvolvimento de site',
               pri: expensive ? 'Alta' : 'Média', valor: expensive ? 8000 : 4500, dept: 'Vendas', respId: 'e3', conf: 94 };
    }
    if (/tráfego|trafico|campanha|ads|anúncio/.test(m)) return { ...r, intencao: 'Novo orçamento', servico: 'Tráfego pago', pri: 'Alta', valor: 4000, dept: 'Vendas', respId: 'e4', conf: 92 };
    if (/social|instagram|rede|conteúdo/.test(m)) return { ...r, intencao: 'Novo orçamento', servico: 'Social media', pri: 'Média', valor: 2000, dept: 'Criativo', respId: 'e9', conf: 88 };
    if (/marca|branding|identidade|logo/.test(m)) return { ...r, intencao: 'Novo orçamento', servico: 'Branding', pri: 'Média', valor: 3000, dept: 'Criativo', respId: 'e8', conf: 89 };
    if (/erro|problema|não está|quebrado|suporte/.test(m)) return { ...r, intencao: 'Suporte', servico: 'Suporte técnico', pri: 'Alta', valor: 0, dept: 'Suporte', respId: 'e10', conf: 93 };
    if (/reclama|péssimo|ruim/.test(m)) return { ...r, intencao: 'Reclamação', servico: 'Qualquer', pri: 'Crítica', valor: 0, dept: 'Vendas', respId: 'e2', conf: 97 };
    if (/reunião|reuniao|agenda|conversar/.test(m)) return { ...r, intencao: 'Reunião', servico: 'Qualquer', pri: 'Média', valor: 0, dept: 'Vendas', respId: 'e2', conf: 82 };
    if (/quanto|valor|custa|preço/.test(m)) return { ...r, intencao: 'Orçamento', servico: 'Consultoria', pri: 'Média', valor: 1500, dept: 'Vendas', respId: 'e4', conf: 84 };
    return r;
  }

  function localRoute(cl) {
    return { ok: true, mock: true, respId: (cl && cl.respId) || 'e6', priority: (cl && cl.pri) || 'Média' };
  }

  // ---------- API pública ----------
  return {
    config,
    http,
    whatsapp,
    ai: { classify, route },
    leads,
    meetings,
    templates
  };
})();