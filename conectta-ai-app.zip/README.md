# 🤖 Conectta.ai

**O recepcionista inteligente para o WhatsApp da sua agência.**

Micro-SaaS de roteamento de conversas com IA para agências de marketing, publicidade, design, criativas, digitais, consultorias e serviços — que recebem centenas de mensagens de clientes por dia.

> **A IA que entende cada mensagem do seu WhatsApp e encaminha o cliente para a pessoa certa.**

---

## 🚀 Como executar

Abra o arquivo **`index.html`** diretamente em um navegador (Chrome, Edge, Firefox). Não precisa de servidor.

**Opcional** — rodar com um servidor local simples:

```bash
# Python 3
python3 -m http.server 8080
# depois acesse http://localhost:8080

# ou Node
npx serve .
```

### Dependências externas (via CDN)
- **Chart.js** (gráficos de Analytics e Leads Perdidos) — carregado da CDN. Sem internet os gráficos são ocultados com segurança; o restante do app funciona offline.
- **Fonte Inter** (Google Fonts) — se indisponível, usa a fonte do sistema.

## 🔐 Acesso de demonstração

Na tela de login, clique **"Entrar"** — as credenciais já vêm preenchidas
(`rafael@horizonte.digital` / `demo1234`). Você entra como **Administrador**, com acesso total.

---

## 🧭 Navegação do produto

| Área | Descrição |
|---|---|
| **Dashboard** | Saudação, KPIs, funil de conversão, leads recentes e "precisa de atenção". |
| **Leads** | CRM leve com tabela completa, busca, filtros, ordenação e paginação. |
| **Leads Perdidos** | Análise de perdas, motivos, etapas, receita estimada perdida e gráficos. |
| **Reuniões** | Agenda com calendário (mês/semana/dia), reuniões futuras e passadas. |
| **Respostas Automáticas** | Templates com variáveis `{{nome}}`, `{{servico}}`, `{{responsavel}}`, etc. |
| **Equipe** | Perfis, especialidades, carga de trabalho, conversão e senioridade. |
| **Roteamento IA** | Regras configuráveis: quem recebe cada tipo de solicitação + modelo de score. |
| **Analytics** | Volume, conversão, funil de receita, leads por serviço/responsável/intenção/prioridade. |
| **Configurações** | Geral, integração WhatsApp, segurança, perfil, notificações e faturamento. |

---

## 🧠 Lógica de IA (Roteamento)

O sistema **não é um chatbot** — é um **recepcionista e roteador inteligente**. O fluxo central:

**Entender → Classificar → Priorizar → Roteiar → Acompanhar → Analisar**

A IA pondera sinais: **intenção, valor do lead, urgência, complexidade, senioridade do vendedor e carga atual**, e aplica as **regras configuráveis** (ex.: site de alto valor → vendedor sênior; reclamação → gerência; financeiro → financeiro).

**Experimente na landing:** na seção **"Teste agora"**, digite uma mensagem (ex.: *"preciso de um site profissional, quanto custa?"*, *"quero cancelar meu contrato"*, *"vocês fazem gestão de tráfego?"*) e veja a IA classificar intenção, prioridade, valor e sugerir o responsável em tempo real. No app, o mesmo classificador está em **+ Novo lead**.

## 📅 Datas dinâmicas

Os dados de demonstração (leads, reuniões e perdas) usam **datas relativas à data atual** — a demo permanece sempre "viva", sem datas antigas fixas.

## 📝 Login e onboarding

A tela de login tem duas abas: **Entrar** e **Criar conta** (onboarding com nome, empresa, e-mail, WhatsApp, nº de atendentes, volume de mensagens, principais serviços e como a equipe distribui leads hoje). Rotulada como **Acesso de demonstração** — nenhuma conta real é necessária.

---

## 🧱 Estrutura

```
coneccta-ai/
├── index.html          # Landing + login + shell do app (SPA)
├── css/styles.css      # Design system (B2B SaaS, pt-BR, responsivo)
├── js/data.js          # Dados de demonstração (fictícios)
├── js/services.js      # Camada de API — WhatsApp + IA + CRM (mock hoje)
├── js/app.js           # Lógica do produto, navegação e interações
└── test-smoke.js       # Smoke test (node) — valida views, interações e Services
```

## 🔌 Camada de API (pronto para produção)

Toda integração externa passa por **`js/services.js`** — o único ponto de contato com
WhatsApp Business API e API de IA. Hoje roda com `config.remote = false` (mock local).

Para ir ao ar:
1. Em `Services.config`, preencha `whatsapp.baseUrl`, `ai.baseUrl` e `api.baseUrl`;
2. Defina `config.remote = true`;
3. Pronto — **nenhuma outra parte do frontend muda**.

Métodos já expostos: `Services.whatsapp.sendText / sendTemplate / onMessage`,
`Services.ai.classify / route`, `Services.leads.list / create / update / updateStatus / assign`,
`Services.meetings.create` e `Services.templates.render`.

> `Services.whatsapp.onMessage(handler)` é o ponto de entrada do webhook: receba a
> mensagem, chame `ai.classify`, depois `leads.create`/roteie — tudo já mapeado.

## 🔌 Nota sobre o WhatsApp
No MVP os dados são **simulados** (nenhum dado real é usado). A arquitetura está pronta para integrar a **API oficial do WhatsApp Business (Cloud API)** sem redesenhar o produto — veja *Configurações → Integração WhatsApp*.

## 💰 Planos
- **Plano Base** — **R$ 450/mês** — roteamento IA, dashboard, CRM, reuniões, respostas automáticas, regras e equipe.
- **Plano Pro** — **R$ 599/mês** — Base + análise de perdas, analytics, roteamento por carga e notificações em tempo real.
- **Plano Avançado** — **R$ 899/mês** — Pro + integração WhatsApp Business, multi-marcas e gerente de conta dedicado.
- **Projetos personalizados — sob consulta.**

---

*Produto de demonstração/MVP. Todos os nomes, empresas e valores são fictícios. Indicadores refletem dados próprios da agência; nenhum número é apresentado como estatística real do setor.*